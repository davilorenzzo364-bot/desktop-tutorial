#!/usr/bin/env python3
# Forja IDE 6.3 - Python + Tkinter
# Standard-library only. External compilers/interpreters must be installed separately.

import os
import sys
import json
import shutil
import zipfile
import tempfile
import urllib.request
import urllib.error
import subprocess
import threading
import re
import importlib.util
import traceback
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

APP_NAME = "Forja IDE"
APP_VERSION = "6.3"
ROOT = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
MODS_DIR = ROOT / "mods"
INSTALLED_DIR = MODS_DIR / "installed"
DISABLED_DIR = MODS_DIR / "disabled"
SETTINGS_DIR = ROOT / "settings"
CACHE_DIR = ROOT / "cache"
SETTINGS_FILE = SETTINGS_DIR / "mods.json"
CONFIG_FILE = ROOT / "config.json"
MAX_PACKAGE_BYTES = 25 * 1024 * 1024

for directory in (INSTALLED_DIR, DISABLED_DIR, SETTINGS_DIR, CACHE_DIR):
    directory.mkdir(parents=True, exist_ok=True)


def read_json(path, fallback):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return fallback


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
    temp.replace(path)


class ModManager:
    """Manages packages. Python entry points are NOT executed automatically."""

    ALLOWED_TYPES = {"theme", "tool", "language", "runner", "panel", "advanced", "plugin"}

    def __init__(self, app):
        self.app = app
        self.settings = read_json(SETTINGS_FILE, {"catalog_url": "", "enabled": {}, "trusted": [], "theme": "default"})
        if not isinstance(self.settings, dict):
            self.settings = {"catalog_url": "", "enabled": {}, "trusted": [], "theme": "default"}
        self.settings.setdefault("catalog_url", "")
        self.settings.setdefault("enabled", {})
        self.settings.setdefault("trusted", [])
        self.settings.setdefault("theme", "default")
        self.mods = []
        self.refresh()

    def save(self):
        write_json(SETTINGS_FILE, self.settings)

    def refresh(self):
        self.mods = []
        for enabled, folder in ((True, INSTALLED_DIR), (False, DISABLED_DIR)):
            if not folder.exists():
                continue
            for child in folder.iterdir():
                if not child.is_dir():
                    continue
                manifest = read_json(child / "mod.json", None)
                if isinstance(manifest, dict) and manifest.get("id") and manifest.get("name"):
                    self.mods.append({"manifest": manifest, "path": child, "enabled": enabled})
        self.mods.sort(key=lambda x: str(x["manifest"].get("name", "")).lower())
        return self.mods

    def validate_manifest(self, manifest):
        if not isinstance(manifest, dict):
            raise ValueError("O manifesto mod.json precisa ser um objeto JSON.")
        required = ("id", "name", "version", "type")
        missing = [key for key in required if not manifest.get(key)]
        if missing:
            raise ValueError("Campos obrigatórios ausentes: " + ", ".join(missing))
        mod_id = str(manifest["id"])
        if not re.fullmatch(r"[A-Za-z0-9._-]{1,80}", mod_id):
            raise ValueError("O ID do mod contém caracteres inválidos.")
        if manifest["type"] not in self.ALLOWED_TYPES:
            raise ValueError("Tipo de mod não reconhecido.")
        min_version = str(manifest.get("min_forja_version", "2.0"))
        try:
            if tuple(map(int, min_version.split(".")[:2])) > tuple(map(int, APP_VERSION.split(".")[:2])):
                raise ValueError("Este mod exige uma versão mais nova do Forja.")
        except ValueError as exc:
            if "exige uma versão" in str(exc):
                raise
            raise ValueError("Versão mínima do Forja inválida.")
        return manifest

    def install_package(self, package_path):
        package_path = Path(package_path)
        if package_path.stat().st_size > MAX_PACKAGE_BYTES:
            raise ValueError("O pacote excede o limite de 25 MB.")
        if not zipfile.is_zipfile(package_path):
            raise ValueError("O arquivo não é um pacote ZIP .forjamod válido.")
        with zipfile.ZipFile(package_path) as zf:
            names = zf.namelist()
            if len(names) > 500:
                raise ValueError("O pacote contém arquivos demais.")
            total = sum(info.file_size for info in zf.infolist())
            if total > 60 * 1024 * 1024:
                raise ValueError("O conteúdo descompactado excede 60 MB.")
            for name in names:
                p = Path(name)
                if p.is_absolute() or ".." in p.parts:
                    raise ValueError("O pacote contém um caminho de arquivo inseguro.")
            manifest_names = [n for n in names if n == "mod.json" or n.endswith("/mod.json")]
            if len(manifest_names) != 1:
                raise ValueError("O pacote deve conter exatamente um mod.json na raiz.")
            manifest_name = manifest_names[0]
            if "/" in manifest_name:
                prefix = manifest_name.rsplit("/", 1)[0] + "/"
            else:
                prefix = ""
            manifest = json.loads(zf.read(manifest_name).decode("utf-8"))
            self.validate_manifest(manifest)
            mod_id = manifest["id"]
            target_parent = INSTALLED_DIR
            target = target_parent / mod_id
            disabled_target = DISABLED_DIR / mod_id
            if target.exists() or disabled_target.exists():
                if not messagebox.askyesno("Substituir mod", f"O mod '{mod_id}' já existe. Substituir a instalação atual?"):
                    return False
                shutil.rmtree(target, ignore_errors=True)
                shutil.rmtree(disabled_target, ignore_errors=True)
            with tempfile.TemporaryDirectory(prefix="forja_mod_") as temp:
                temp_path = Path(temp)
                for info in zf.infolist():
                    name = info.filename
                    if prefix and not name.startswith(prefix):
                        continue
                    relative = name[len(prefix):] if prefix else name
                    if not relative:
                        continue
                    dest = temp_path / relative
                    if info.is_dir():
                        dest.mkdir(parents=True, exist_ok=True)
                    else:
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(info) as src, open(dest, "wb") as dst:
                            shutil.copyfileobj(src, dst)
                if not (temp_path / "mod.json").exists():
                    raise ValueError("Não foi possível localizar mod.json na raiz do mod.")
                self.validate_manifest(read_json(temp_path / "mod.json", None))
                shutil.move(str(temp_path), str(target))
            self.settings.setdefault("enabled", {})[mod_id] = True
            self.save()
            self.refresh()
            return True

    def toggle(self, mod, enable):
        manifest = mod["manifest"]
        mod_id = manifest["id"]
        source = mod["path"]
        target = (INSTALLED_DIR if enable else DISABLED_DIR) / mod_id
        if source.resolve() == target.resolve():
            return
        if target.exists():
            raise ValueError("Já existe uma pasta com esse ID.")
        shutil.move(str(source), str(target))
        self.settings.setdefault("enabled", {})[mod_id] = bool(enable)
        self.save()
        self.refresh()

    def remove(self, mod):
        name = mod["manifest"].get("name", mod["manifest"]["id"])
        if not messagebox.askyesno("Remover mod", f"Remover '{name}' do Forja?"):
            return False
        shutil.rmtree(mod["path"])
        self.settings.setdefault("enabled", {}).pop(mod["manifest"]["id"], None)
        self.save()
        self.refresh()
        return True

    def catalog_url(self):
        return str(self.settings.get("catalog_url", "")).strip()

    def fetch_catalog(self):
        url = self.catalog_url()
        if not url:
            raise ValueError("Configure a URL do catálogo nas configurações da loja.")
        if not url.lower().startswith("https://"):
            raise ValueError("Por segurança, a URL do catálogo precisa usar HTTPS.")
        request = urllib.request.Request(url, headers={"User-Agent": "ForjaIDE/3.0"})
        with urllib.request.urlopen(request, timeout=12) as response:
            data = response.read(2 * 1024 * 1024 + 1)
        if len(data) > 2 * 1024 * 1024:
            raise ValueError("O catálogo é grande demais (limite: 2 MB).")
        catalog = json.loads(data.decode("utf-8"))
        if not isinstance(catalog, dict) or not isinstance(catalog.get("mods", []), list):
            raise ValueError("Formato de catálogo inválido.")
        return catalog.get("mods", [])

    def download_mod(self, item):
        url = str(item.get("url", ""))
        if not url.lower().startswith("https://"):
            raise ValueError("O download precisa usar HTTPS.")
        filename = str(item.get("filename", item.get("id", "mod") + ".forjamod"))
        if not filename.endswith(".forjamod"):
            filename += ".forjamod"
        request = urllib.request.Request(url, headers={"User-Agent": "ForjaIDE/3.0"})
        with urllib.request.urlopen(request, timeout=20) as response:
            data = response.read(MAX_PACKAGE_BYTES + 1)
        if len(data) > MAX_PACKAGE_BYTES:
            raise ValueError("O pacote excede 25 MB.")
        dest = CACHE_DIR / filename
        dest.write_bytes(data)
        return dest


class ForjaModAPI:
    """Small, explicit API exposed to trusted Python mods."""
    def __init__(self, app, mod_id):
        self.app = app
        self.mod_id = mod_id

    def register_command(self, label, callback):
        if not isinstance(label, str) or not label.strip() or not callable(callback):
            raise ValueError("register_command(label, callback) requer um nome e uma função.")
        self.app.mod_commands.append({"mod_id": self.mod_id, "label": label.strip(), "callback": callback})

    def insert_text(self, text):
        self.app.editor.insert("insert", str(text))
        self.app.editor.focus_set()
        self.app.update_line_numbers()

    def get_text(self):
        return self.app.editor.get("1.0", "end-1c")

    def set_text(self, text):
        self.app.editor.delete("1.0", "end")
        self.app.editor.insert("1.0", str(text))
        self.app.update_line_numbers()

    def show_message(self, title, message):
        messagebox.showinfo(str(title), str(message), parent=self.app)

    def set_theme(self, theme):
        """Apply editor colors. Keys: background, foreground, cursor, gutter_background, gutter_foreground."""
        if not isinstance(theme, dict):
            raise ValueError("O tema precisa ser um dicionário.")
        allowed = {"background", "foreground", "cursor", "gutter_background", "gutter_foreground", "console_background", "console_foreground"}
        if set(theme) - allowed:
            raise ValueError("O tema contém chaves desconhecidas.")
        self.app.apply_custom_theme(theme)


class ForjaApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self.geometry("1100x720")
        self.minsize(780, 520)
        self.current_file = None
        self.mod_project_dir = None
        self.session_config = read_json(CONFIG_FILE, {})
        if not isinstance(self.session_config, dict):
            self.session_config = {}
        self.selected_language = tk.StringVar(value=self.session_config.get("ultima_linguagem", "C"))
        self._restoring_session = True
        self.process = None
        self.output_queue = []
        self.mod_manager = ModManager(self)
        self.mod_commands = []
        self.loaded_mods = {}
        self._build_menu()
        self._build_ui()
        self.apply_theme()
        self.restore_session()
        self._restoring_session = False
        if self.current_file is None:
            self.show_welcome()
        else:
            self.show_editor()
        self.refresh_mod_list()
        self.load_enabled_mods(startup=True)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def save_session_config(self):
        """Persist the last opened file and selected language."""
        if getattr(self, "_restoring_session", False):
            return
        data = {
            "ultimo_arquivo": str(self.current_file.resolve()) if self.current_file else "",
            "ultima_linguagem": self.selected_language.get() or "C",
        }
        try:
            write_json(CONFIG_FILE, data)
        except OSError as exc:
            # Config failure should not prevent editing or saving code.
            if hasattr(self, "status"):
                self.status.set(f"Aviso: não foi possível salvar config.json: {exc}")

    def restore_session(self):
        """Restore the last language and, if it still exists, the last file."""
        valid_languages = set(self.language_picker.cget("values")) if hasattr(self, "language_picker") else {"C"}
        saved_language = self.session_config.get("ultima_linguagem", "C")
        if saved_language not in valid_languages:
            saved_language = "C"
        saved_path = self.session_config.get("ultimo_arquivo", "")
        if saved_path:
            try:
                path = Path(saved_path).expanduser()
                if path.is_file():
                    content = path.read_text(encoding="utf-8")
                    self.editor.delete("1.0", "end")
                    self.editor.insert("1.0", content)
                    self.current_file = path
                    self.title(f"{APP_NAME} {APP_VERSION} - {path.name}")
                    self.update_line_numbers()
                    self.highlight_syntax()
                    self.refresh_sidebar_tree()
                    self.status.set(f"Sessão restaurada: {path.name}")
                else:
                    self.current_file = None
            except (OSError, UnicodeError, ValueError):
                self.current_file = None
        self.selected_language.set(saved_language)
        if self.current_file is None:
            self.title(f"{APP_NAME} {APP_VERSION} - Novo arquivo ({saved_language})")
        self.highlight_syntax()
        self.save_session_config()

    def _build_menu(self):
        menu = tk.Menu(self)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(label="Novo", accelerator="Ctrl+N", command=self.new_file)
        file_menu.add_command(label="Abrir arquivo...", accelerator="Ctrl+O", command=self.open_file)
        file_menu.add_command(label="Abrir pasta de projeto...", command=self.open_project_folder)
        file_menu.add_command(label="Salvar", accelerator="Ctrl+S", command=self.save_file)
        file_menu.add_command(label="Salvar como...", command=self.save_as)
        file_menu.add_separator()
        file_menu.add_command(label="Sair", command=self.on_close)
        menu.add_cascade(label="Arquivo", menu=file_menu)
        run_menu = tk.Menu(menu, tearoff=False)
        run_menu.add_command(label="Executar", accelerator="F5", command=self.run_code)
        run_menu.add_command(label="Depurar Python", accelerator="F6", command=self.debug_code)
        run_menu.add_command(label="Arduino: compilar e transferir", accelerator="F7", command=self.upload_arduino)
        run_menu.add_command(label="Parar execução", command=self.stop_code)
        menu.add_cascade(label="Executar", menu=run_menu)
        mods_menu = tk.Menu(menu, tearoff=False)
        mods_menu.add_command(label="Abrir gerenciador de Mods", command=lambda: self.notebook.select(self.mods_tab))
        mods_menu.add_command(label="Instalar arquivo .forjamod...", command=self.install_mod_dialog)
        mods_menu.add_command(label="Recarregar mods ativos", command=self.reload_mods)
        mods_menu.add_command(label="Comandos dos mods", command=self.show_mod_commands)
        mods_menu.add_separator()
        self.mods_commands_menu = tk.Menu(mods_menu, tearoff=False)
        mods_menu.add_cascade(label="Executar comando", menu=self.mods_commands_menu)
        menu.add_cascade(label="Mods", menu=mods_menu)
        help_menu = tk.Menu(menu, tearoff=False)
        help_menu.add_command(label="Sobre o Forja", command=self.about)
        help_menu.add_command(label="Segurança dos Mods", command=self.security_info)
        menu.add_cascade(label="Ajuda", menu=help_menu)
        self.config(menu=menu)
        self.bind_all("<Control-n>", lambda e: self.new_file())
        self.bind_all("<Control-o>", lambda e: self.open_file())
        self.bind_all("<Control-s>", lambda e: self.save_file())
        self.bind_all("<F5>", lambda e: self.run_code())
        self.bind_all("<F6>", lambda e: self.debug_code())
        self.bind_all("<F7>", lambda e: self.upload_arduino())

    def _build_ui(self):
        shell = ttk.Panedwindow(self, orient="horizontal")
        shell.pack(fill="both", expand=True, padx=7, pady=7)
        sidebar = ttk.Frame(shell, padding=5)
        main_area = ttk.Frame(shell)
        shell.add(sidebar, weight=1)
        shell.add(main_area, weight=4)
        ttk.Label(sidebar, text="EXPLORADOR", font=("TkDefaultFont", 10, "bold")).pack(anchor="w", pady=(0, 5))
        side_buttons = ttk.Frame(sidebar)
        side_buttons.pack(fill="x", pady=(0, 5))
        ttk.Button(side_buttons, text="Abrir pasta", command=self.open_project_folder).pack(side="left", fill="x", expand=True)
        ttk.Button(side_buttons, text="Abrir arquivo", command=self.open_file).pack(side="left", fill="x", expand=True, padx=(4, 0))
        self.sidebar_tree = ttk.Treeview(sidebar, show="tree", selectmode="browse")
        self.sidebar_tree.pack(fill="both", expand=True)
        self.sidebar_tree.bind("<Double-1>", self.open_sidebar_item)
        self.notebook = ttk.Notebook(main_area)
        self.notebook.pack(fill="both", expand=True)

        editor_tab = ttk.Frame(self.notebook)
        self.editor_tab = editor_tab
        self.notebook.add(editor_tab, text="Editor")
        editor_tab.rowconfigure(1, weight=1)
        editor_tab.columnconfigure(1, weight=1)
        lang_bar = ttk.Frame(editor_tab)
        lang_bar.grid(row=0, column=0, columnspan=3, sticky="ew", padx=5, pady=5)
        ttk.Label(lang_bar, text="Linguagem:").pack(side="left", padx=(0, 6))
        self.language_picker = ttk.Combobox(
            lang_bar, textvariable=self.selected_language,
            values=("C", "C++", "C#", "Java", "JavaScript", "TypeScript", "Python", "Go", "Rust", "Kotlin", "Ruby", "Lua", "Luau", "FreeBASIC", "PHP", "SQL", "Arduino"), state="readonly", width=16
        )
        self.language_picker.pack(side="left")
        self.language_picker.bind("<<ComboboxSelected>>", self.on_language_change)
        ttk.Label(lang_bar, text="F5 Executar · F6 Depurar Python · F7 Arduino").pack(side="left", padx=10)
        ttk.Button(lang_bar, text="Arduino (F7)", command=self.upload_arduino).pack(side="right", padx=4)
        ttk.Button(lang_bar, text="Depurar", command=self.debug_code).pack(side="right", padx=4)
        ttk.Button(lang_bar, text="Executar", command=self.run_code).pack(side="right", padx=4)
        self.line_numbers = tk.Text(editor_tab, width=4, padx=5, takefocus=0, state="disabled", wrap="none")
        self.line_numbers.grid(row=1, column=0, sticky="ns")
        self.editor = tk.Text(editor_tab, undo=True, wrap="none", font=("Consolas", 11), tabs=("4c",))
        self.editor.grid(row=1, column=1, sticky="nsew")
        yscroll = ttk.Scrollbar(editor_tab, orient="vertical", command=self._scroll_editor)
        yscroll.grid(row=1, column=2, sticky="ns")
        self.editor.configure(yscrollcommand=yscroll.set)
        xscroll = ttk.Scrollbar(editor_tab, orient="horizontal", command=self.editor.xview)
        xscroll.grid(row=2, column=1, sticky="ew")
        self.editor.configure(xscrollcommand=xscroll.set)
        self.editor.bind("<KeyRelease>", self.on_editor_keyrelease)
        self.editor.bind("<KeyPress>", self.on_editor_keypress)
        self.editor.bind("<Return>", self.auto_indent)
        self.editor.bind("<Tab>", self.insert_tab)
        self.editor.bind("<Control-space>", self.autocomplete)
        self.editor.tag_config("current_line", background="#f3f6fa")
        self.completion_popup = None
        self.completion_list = None
        self.update_line_numbers()

        console_tab = ttk.Frame(self.notebook)
        self.notebook.add(console_tab, text="Console")
        console_tab.rowconfigure(0, weight=1)
        console_tab.columnconfigure(0, weight=1)
        self.console = tk.Text(console_tab, state="disabled", wrap="word", font=("Consolas", 10))
        self.console.grid(row=0, column=0, sticky="nsew")
        con_scroll = ttk.Scrollbar(console_tab, command=self.console.yview)
        con_scroll.grid(row=0, column=1, sticky="ns")
        self.console.configure(yscrollcommand=con_scroll.set)
        # Terminal integrado inspirado no VS Code: saída escura, prompt de comando,
        # execução de comandos do sistema quando não há programa ativo e stdin para programas.
        terminal_bar = ttk.Frame(console_tab)
        terminal_bar.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(6, 2))
        terminal_bar.columnconfigure(1, weight=1)
        ttk.Label(terminal_bar, text="TERMINAL", font=("TkDefaultFont", 9, "bold")).grid(row=0, column=0, padx=(2, 8))
        self.terminal_prompt = ttk.Label(terminal_bar, text=self._terminal_prompt_text())
        self.terminal_prompt.grid(row=0, column=1, sticky="w")
        ttk.Button(terminal_bar, text="Limpar", command=self.clear_terminal).grid(row=0, column=2, padx=3)
        bottom = ttk.Frame(console_tab)
        bottom.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(2, 4))
        bottom.columnconfigure(1, weight=1)
        self.terminal_symbol = ttk.Label(bottom, text=">", font=("Consolas", 11, "bold"))
        self.terminal_symbol.pack(side="left", padx=(5, 6))
        self.console_input = ttk.Entry(bottom, font=("Consolas", 10))
        self.console_input.pack(side="left", fill="x", expand=True)
        self.console_input.bind("<Return>", self.send_input)
        ttk.Button(bottom, text="Enviar", command=self.send_input).pack(side="left", padx=4)
        ttk.Button(bottom, text="Parar", command=self.stop_code).pack(side="left")

        self.mods_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.mods_tab, text="Mods")
        self._build_mods_tab(self.mods_tab)

        self.creator_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.creator_tab, text="Criar Mods")
        self._build_creator_tab(self.creator_tab)

        # Tela inicial: fica como aba separada e é selecionada quando não há arquivo aberto.
        self.welcome_tab = ttk.Frame(self.notebook, padding=24)
        self.notebook.add(self.welcome_tab, text="Início")
        welcome_content = ttk.Frame(self.welcome_tab)
        welcome_content.place(relx=0.5, rely=0.43, anchor="center")
        ttk.Label(
            welcome_content, text="Bem-vindo à Forja",
            font=("TkDefaultFont", 24, "bold")
        ).pack(pady=(0, 8))
        ttk.Label(
            welcome_content,
            text="O que vamos construir hoje? Abra um projeto ou comece a programar.",
            font=("TkDefaultFont", 10)
        ).pack(pady=(0, 24))
        welcome_buttons = ttk.Frame(welcome_content)
        welcome_buttons.pack()
        ttk.Button(
            welcome_buttons, text="＋  Criar Novo Arquivo", command=self.new_file,
            width=28
        ).pack(fill="x", pady=5, ipady=7)
        ttk.Button(
            welcome_buttons, text="📄  Abrir Arquivo", command=self.open_file,
            width=28
        ).pack(fill="x", pady=5, ipady=7)
        ttk.Button(
            welcome_buttons, text="📁  Abrir Pasta", command=self.open_project_folder,
            width=28
        ).pack(fill="x", pady=5, ipady=7)
        ttk.Label(
            welcome_content, text="Forja IDE 6.3 · leve, extensível e feita para criar",
            foreground="#777777"
        ).pack(pady=(24, 0))

        self.status = tk.StringVar(value="Pronto")
        ttk.Label(self, textvariable=self.status, anchor="w").pack(fill="x", padx=8, pady=(0, 5))

    def _build_mods_tab(self, parent):
        top = ttk.Frame(parent)
        top.pack(fill="x", padx=8, pady=8)
        ttk.Label(top, text="Gerenciador de Mods", font=("TkDefaultFont", 13, "bold")).pack(side="left")
        ttk.Button(top, text="Instalar arquivo...", command=self.install_mod_dialog).pack(side="right", padx=3)
        ttk.Button(top, text="Atualizar lista", command=self.refresh_mod_list).pack(side="right", padx=3)

        columns = ("state", "type", "version", "description")
        self.mod_tree = ttk.Treeview(parent, columns=columns, show="tree headings", selectmode="browse")
        self.mod_tree.heading("#0", text="Mod")
        self.mod_tree.heading("state", text="Estado")
        self.mod_tree.heading("type", text="Tipo")
        self.mod_tree.heading("version", text="Versão")
        self.mod_tree.heading("description", text="Descrição")
        self.mod_tree.column("#0", width=190)
        self.mod_tree.column("state", width=90, anchor="center")
        self.mod_tree.column("type", width=100, anchor="center")
        self.mod_tree.column("version", width=75, anchor="center")
        self.mod_tree.column("description", width=360)
        self.mod_tree.pack(fill="both", expand=True, padx=8, pady=(0, 6))
        actions = ttk.Frame(parent)
        actions.pack(fill="x", padx=8, pady=5)
        ttk.Button(actions, text="Ativar", command=lambda: self.toggle_selected_mod(True)).pack(side="left", padx=2)
        ttk.Button(actions, text="Desativar", command=lambda: self.toggle_selected_mod(False)).pack(side="left", padx=2)
        ttk.Button(actions, text="Remover", command=self.remove_selected_mod).pack(side="left", padx=2)
        ttk.Button(actions, text="Detalhes", command=self.show_mod_details).pack(side="left", padx=2)

        self.store_frame = ttk.LabelFrame(parent, text="Loja integrada")
        self.store_frame.pack(fill="x", padx=8, pady=8)
        ttk.Label(self.store_frame, text="A loja usa um catálogo JSON HTTPS configurado pelo usuário.").pack(anchor="w", padx=8, pady=(5, 2))
        store_buttons = ttk.Frame(self.store_frame)
        store_buttons.pack(fill="x", padx=6, pady=4)
        ttk.Button(store_buttons, text="Configurar catálogo", command=self.configure_catalog).pack(side="left", padx=2)
        ttk.Button(store_buttons, text="Pesquisar na loja", command=self.open_store).pack(side="left", padx=2)
        ttk.Label(self.store_frame, text="A loja ainda precisa de um catálogo hospedado; não vem com um servidor oficial pré-configurado.", foreground="#8a5b00", wraplength=850).pack(anchor="w", padx=8, pady=(0, 6))

    def _build_creator_tab(self, parent):
        """A guided workspace for creating, browsing and packaging mods."""
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(1, weight=1)
        intro = ttk.Frame(parent)
        intro.grid(row=0, column=0, sticky="ew", padx=10, pady=8)
        ttk.Label(intro, text="Oficina de Mods", font=("TkDefaultFont", 14, "bold")).pack(anchor="w")
        ttk.Label(intro, text="Crie um projeto pronto, edite os arquivos e gere um pacote .forjamod sem sair do Forja.", wraplength=950).pack(anchor="w", pady=(3, 7))
        controls = ttk.Frame(intro)
        controls.pack(fill="x")
        ttk.Button(controls, text="Novo projeto de mod...", command=self.create_mod_project).pack(side="left", padx=(0, 5))
        ttk.Button(controls, text="Abrir pasta...", command=self.open_project_folder).pack(side="left", padx=5)
        ttk.Button(controls, text="Abrir arquivo...", command=self.open_file).pack(side="left", padx=5)
        ttk.Button(controls, text="Abrir pasta no sistema", command=self.reveal_project_folder).pack(side="left", padx=5)
        ttk.Button(controls, text="Empacotar .forjamod", command=self.package_mod_project).pack(side="left", padx=5)

        body = ttk.Panedwindow(parent, orient="horizontal")
        body.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))
        explorer = ttk.Frame(body, padding=5)
        workspace = ttk.Frame(body, padding=5)
        body.add(explorer, weight=1)
        body.add(workspace, weight=3)
        ttk.Label(explorer, text="Arquivos do projeto", font=("TkDefaultFont", 10, "bold")).pack(anchor="w", pady=(0, 5))
        self.project_path_label = ttk.Label(explorer, text="Nenhum projeto aberto", wraplength=250)
        self.project_path_label.pack(fill="x", pady=(0, 5))
        self.project_tree = ttk.Treeview(explorer, columns=("path",), show="tree", selectmode="browse")
        self.project_tree.pack(fill="both", expand=True)
        self.project_tree.bind("<Double-1>", self.open_project_tree_item)
        tree_actions = ttk.Frame(explorer)
        tree_actions.pack(fill="x", pady=5)
        ttk.Button(tree_actions, text="Atualizar", command=self.refresh_project_tree).pack(side="left", padx=(0, 4))
        ttk.Button(tree_actions, text="Abrir selecionado", command=self.open_project_tree_item).pack(side="left")

        ttk.Label(workspace, text="Passo a passo", font=("TkDefaultFont", 10, "bold")).pack(anchor="w", pady=(0, 6))
        instructions = (
            "1. Clique em ‘Novo projeto de mod’.\n"
            "2. Escolha Tema (mais simples) ou Plugin Python (para comandos).\n"
            "3. Selecione um arquivo na árvore para abri-lo no editor principal.\n"
            "4. Edite e salve com Ctrl+S.\n"
            "5. Clique em ‘Empacotar .forjamod’ e instale o pacote pela aba Mods.\n\n"
            "Tema: usa theme.json e não executa código.\n"
            "Plugin Python: usa mod.py; só ative código que você leu e em que confia."
        )
        ttk.Label(workspace, text=instructions, justify="left", wraplength=600).pack(anchor="nw", fill="x")
        self.creator_help = ttk.Label(workspace, text="Dica: comece por um tema, pois ele não precisa de programação.", foreground="#26734d", wraplength=600)
        self.creator_help.pack(anchor="w", pady=12)

    def create_mod_project(self):
        win = tk.Toplevel(self)
        win.title("Novo projeto de mod")
        win.transient(self)
        win.grab_set()
        win.resizable(False, False)
        frm = ttk.Frame(win, padding=14)
        frm.pack(fill="both", expand=True)
        name_var = tk.StringVar(value="Meu Mod")
        id_var = tk.StringVar(value="criador.meu_mod")
        author_var = tk.StringVar(value="Criador")
        desc_var = tk.StringVar(value="Meu primeiro mod para o Forja IDE")
        kind_var = tk.StringVar(value="Tema")
        parent_var = tk.StringVar(value=str(Path.home() / "ForjaMods"))
        ttk.Label(frm, text="Nome do mod:").grid(row=0, column=0, sticky="w", pady=4)
        ttk.Entry(frm, textvariable=name_var, width=42).grid(row=0, column=1, sticky="ew", pady=4)
        ttk.Label(frm, text="ID único (ex.: criador.meu_mod):").grid(row=1, column=0, sticky="w", pady=4)
        ttk.Entry(frm, textvariable=id_var, width=42).grid(row=1, column=1, sticky="ew", pady=4)
        ttk.Label(frm, text="Autor:").grid(row=2, column=0, sticky="w", pady=4)
        ttk.Entry(frm, textvariable=author_var, width=42).grid(row=2, column=1, sticky="ew", pady=4)
        ttk.Label(frm, text="Descrição:").grid(row=3, column=0, sticky="w", pady=4)
        ttk.Entry(frm, textvariable=desc_var, width=42).grid(row=3, column=1, sticky="ew", pady=4)
        ttk.Label(frm, text="Tipo:").grid(row=4, column=0, sticky="w", pady=4)
        ttk.Combobox(frm, textvariable=kind_var, values=("Tema", "Plugin Python"), state="readonly", width=39).grid(row=4, column=1, sticky="ew", pady=4)
        ttk.Label(frm, text="Criar dentro de:").grid(row=5, column=0, sticky="w", pady=4)
        pathrow = ttk.Frame(frm)
        pathrow.grid(row=5, column=1, sticky="ew", pady=4)
        ttk.Entry(pathrow, textvariable=parent_var, width=32).pack(side="left", fill="x", expand=True)
        def choose_parent():
            chosen = filedialog.askdirectory(title="Escolha onde criar o projeto", initialdir=parent_var.get() or str(Path.home()), parent=win)
            if chosen:
                parent_var.set(chosen)
        ttk.Button(pathrow, text="Procurar...", command=choose_parent).pack(side="left", padx=(5, 0))
        buttons = ttk.Frame(frm)
        buttons.grid(row=6, column=0, columnspan=2, sticky="e", pady=(12, 0))
        def create():
            name = name_var.get().strip()
            mod_id = id_var.get().strip()
            author = author_var.get().strip() or "Não informado"
            desc = desc_var.get().strip() or "Mod criado com a Oficina de Mods do Forja IDE"
            if not name or not re.fullmatch(r"[A-Za-z0-9._-]+", mod_id):
                messagebox.showerror("Dados inválidos", "Informe um nome e um ID com apenas letras, números, ponto, hífen ou sublinhado.", parent=win)
                return
            base = Path(parent_var.get()).expanduser()
            project = base / re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._")
            if project.exists() and any(project.iterdir()):
                if not messagebox.askyesno("Pasta já existe", f"A pasta já existe e não está vazia:\n{project}\n\nDeseja usar/mesclar essa pasta?", parent=win):
                    return
            try:
                project.mkdir(parents=True, exist_ok=True)
                kind = kind_var.get()
                manifest = {"id": mod_id, "name": name, "version": "1.0.0", "api_version": 1,
                            "min_forja_version": "4.1", "type": "theme" if kind == "Tema" else "plugin",
                            "author": author, "description": desc, "permissions": [] if kind == "Tema" else ["editor.read", "editor.write"]}
                (project / "mod.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
                if kind == "Tema":
                    theme = {"background": "#171923", "foreground": "#e6e8ef", "cursor": "#ffffff",
                             "gutter_background": "#222636", "gutter_foreground": "#aab1c5",
                             "console_background": "#11131a", "console_foreground": "#e6e8ef"}
                    (project / "theme.json").write_text(json.dumps(theme, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
                    readme = f"# {name}\n\n{desc}\n\nMod de tema para Forja IDE. Edite as cores em `theme.json`.\n"
                else:
                    code = 'def register(api):\n    \"\"\"Registra comandos no Forja IDE. Leia SDK_MODS.md para a API completa.\"\"\"\n    def inserir_exemplo():\n        api.insert_text(\"Olá! Este texto veio do meu mod.\\\\n\")\n\n    api.register_command(\"Inserir texto de exemplo\", inserir_exemplo)\n'
                    (project / "mod.py").write_text(code, encoding="utf-8")
                    readme = f"# {name}\n\n{desc}\n\nPlugin Python para Forja IDE. Leia o código antes de ativar: plugins Python podem acessar recursos do computador.\n"
                (project / "README.md").write_text(readme, encoding="utf-8")
                self.mod_project_dir = project
                self.refresh_project_tree()
                self.creator_help.configure(text=f"Projeto criado em: {project}\nAbra um arquivo na árvore para editá-lo. Quando terminar, empacote como .forjamod.")
                self.status.set(f"Projeto de mod criado: {project.name}")
                win.destroy()
                self.notebook.select(self.creator_tab)
                messagebox.showinfo("Projeto criado", f"O projeto foi criado com sucesso:\n{project}\n\nUse a árvore da Oficina de Mods para abrir e editar os arquivos.", parent=self)
            except Exception as exc:
                messagebox.showerror("Erro ao criar projeto", str(exc), parent=win)
        ttk.Button(buttons, text="Cancelar", command=win.destroy).pack(side="right", padx=4)
        ttk.Button(buttons, text="Criar projeto", command=create).pack(side="right", padx=4)
        win.bind("<Return>", lambda _e: create())

    def refresh_sidebar_tree(self):
        if not hasattr(self, "sidebar_tree"):
            return
        self.sidebar_tree.delete(*self.sidebar_tree.get_children())
        if self.mod_project_dir and self.mod_project_dir.is_dir():
            root_id = self.sidebar_tree.insert("", "end", text="📁 " + self.mod_project_dir.name, values=(str(self.mod_project_dir),), open=True)
            def add(parent_id, folder, depth=0):
                if depth > 5:
                    return
                try:
                    children = sorted(folder.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
                except OSError:
                    return
                for child in children:
                    if child.name in {"__pycache__", ".git", ".venv", "venv", "node_modules"}:
                        continue
                    item = self.sidebar_tree.insert(parent_id, "end", text=("📁 " if child.is_dir() else "📄 ") + child.name, values=(str(child),), open=False)
                    if child.is_dir():
                        add(item, child, depth + 1)
            add(root_id, self.mod_project_dir)
        if self.current_file and self.current_file.exists():
            root_id = self.sidebar_tree.insert("", "end", text="ARQUIVO ATUAL", values=(str(self.current_file),), open=True)
            self.sidebar_tree.insert(root_id, "end", text="📄 " + self.current_file.name, values=(str(self.current_file),))

    def open_sidebar_item(self, event=None):
        sel = self.sidebar_tree.selection()
        if not sel:
            return
        values = self.sidebar_tree.item(sel[0], "values")
        if not values:
            return
        path = Path(values[0])
        if path.is_dir():
            self.sidebar_tree.item(sel[0], open=not self.sidebar_tree.item(sel[0], "open"))
            return
        try:
            self.editor.delete("1.0", "end")
            self.editor.insert("1.0", path.read_text(encoding="utf-8"))
            self.current_file = path
            self.sync_language_to_file()
            self.title(f"{APP_NAME} {APP_VERSION} - {path.name}")
            self.update_line_numbers()
            self.show_editor()
            self.refresh_sidebar_tree()
            self.status.set(f"Arquivo aberto: {path.name}")
            self.save_session_config()
        except (OSError, UnicodeError) as exc:
            messagebox.showerror("Abrir arquivo", f"Não foi possível abrir como texto:\n{exc}")

    def open_project_folder(self):
        folder = filedialog.askdirectory(title="Abrir pasta de projeto", initialdir=str(self.mod_project_dir or Path.home()))
        if not folder:
            return
        self.mod_project_dir = Path(folder)
        self.refresh_project_tree()
        self.refresh_sidebar_tree()
        self.notebook.select(self.creator_tab)
        self.status.set(f"Pasta de projeto aberta: {self.mod_project_dir}")

    def reveal_project_folder(self):
        if not self.mod_project_dir or not self.mod_project_dir.exists():
            messagebox.showinfo("Oficina de Mods", "Abra uma pasta de projeto primeiro.")
            return
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(self.mod_project_dir))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(self.mod_project_dir)])
            else:
                subprocess.Popen(["xdg-open", str(self.mod_project_dir)])
        except Exception as exc:
            messagebox.showerror("Abrir pasta", str(exc))

    def refresh_project_tree(self):
        if not hasattr(self, "project_tree"):
            return
        self.project_tree.delete(*self.project_tree.get_children())
        if not self.mod_project_dir or not self.mod_project_dir.exists():
            self.project_path_label.configure(text="Nenhum projeto aberto")
            return
        self.project_path_label.configure(text=str(self.mod_project_dir))
        root_id = self.project_tree.insert("", "end", text=self.mod_project_dir.name, open=True, values=(str(self.mod_project_dir),))
        def add_children(parent_id, folder, depth=0):
            if depth > 8:
                return
            try:
                children = sorted(folder.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
            except OSError:
                return
            for child in children:
                if child.name in {"__pycache__", ".git", ".venv", "venv"}:
                    continue
                item = self.project_tree.insert(parent_id, "end", text=child.name, open=False, values=(str(child),))
                if child.is_dir():
                    add_children(item, child, depth + 1)
        add_children(root_id, self.mod_project_dir)
        self.refresh_sidebar_tree()

    def open_project_tree_item(self, event=None):
        selected = self.project_tree.selection()
        if not selected:
            return
        values = self.project_tree.item(selected[0], "values")
        if not values:
            return
        path = Path(values[0])
        if path.is_dir():
            if event is None:
                self.project_tree.item(selected[0], open=not self.project_tree.item(selected[0], "open"))
            return
        try:
            content = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            messagebox.showerror("Abrir arquivo do projeto", f"Não foi possível abrir este arquivo como texto:\n{exc}")
            return
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", content)
        self.current_file = path
        self.sync_language_to_file()
        self.refresh_sidebar_tree()
        self.show_editor()
        self.title(f"{APP_NAME} {APP_VERSION} - {path.name}")
        self.update_line_numbers()
        self.highlight_syntax()
        self.notebook.select(0)
        self.status.set(f"Arquivo do projeto aberto: {path.name}")
        self.save_session_config()

    def package_mod_project(self):
        if not self.mod_project_dir or not self.mod_project_dir.is_dir():
            messagebox.showinfo("Empacotar mod", "Crie ou abra uma pasta de projeto primeiro.")
            return
        manifest_path = self.mod_project_dir / "mod.json"
        if not manifest_path.is_file():
            messagebox.showerror("Empacotar mod", "Não encontrei mod.json na raiz da pasta selecionada.")
            return
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            self.mod_manager.validate_manifest(manifest)
            target = filedialog.asksaveasfilename(title="Salvar pacote do mod", initialdir=str(self.mod_project_dir.parent),
                initialfile=f"{self.mod_project_dir.name}.forjamod", defaultextension=".forjamod",
                filetypes=[("Pacote de mod Forja", "*.forjamod")])
            if not target:
                return
            with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
                for item in self.mod_project_dir.rglob("*"):
                    if item.is_file() and not any(part in {"__pycache__", ".git", ".venv", "venv"} for part in item.parts):
                        archive.write(item, item.relative_to(self.mod_project_dir).as_posix())
            self.status.set(f"Pacote criado: {Path(target).name}")
            if messagebox.askyesno("Pacote criado", f"Pacote criado com sucesso:\n{target}\n\nDeseja abrir a aba Mods para instalar agora?"):
                self.notebook.select(self.mods_tab)
                if messagebox.askyesno("Instalar agora", "Escolha o pacote recém-criado na janela seguinte."):
                    self.install_mod_dialog()
        except Exception as exc:
            messagebox.showerror("Empacotar mod", f"Não foi possível criar o pacote:\n{exc}")

    def _scroll_editor(self, *args):
        self.editor.yview(*args)
        self.line_numbers.yview(*args)

    def update_line_numbers(self, event=None):
        count = int(self.editor.index("end-1c").split(".")[0])
        self.line_numbers.configure(state="normal")
        self.line_numbers.delete("1.0", "end")
        self.line_numbers.insert("1.0", "\n".join(str(i) for i in range(1, count + 1)))
        self.line_numbers.configure(state="disabled")
        self.line_numbers.yview_moveto(self.editor.yview()[0])
        self.highlight_syntax()

    def highlight_syntax(self):
        for tag in ("keyword", "string", "comment", "number"):
            self.editor.tag_remove(tag, "1.0", "end")
        text = self.editor.get("1.0", "end-1c")
        ext = self.current_file.suffix.lower() if self.current_file else self.suggested_extension()
        if ext in (".c", ".h", ".cpp", ".cc", ".cxx", ".hpp", ".java", ".cs", ".go", ".rs"):
            keywords = r"\b(auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|if|int|long|return|short|signed|sizeof|static|struct|switch|typedef|union|unsigned|void|volatile|while|class|public|private|protected|final|new|this|extends|implements|package|import|boolean|byte|catch|try|throw|throws|null|true|false|String|System|main|namespace|using|var|let|func|fn|mut|impl|trait|pub|mod|match|defer|go|chan|select|interface|map|range|fallthrough|where|async|await|virtual|override|static|readonly|decimal|dynamic|Console|def|elif|None|True|False|and|or|not|lambda|yield|pass|with|as|is|from|global|nonlocal|assert|raise|except|finally|self|print|package|func|type|const|goto|unsafe)\b"
            comments = r"//.*|/\*[\s\S]*?\*/"
        elif ext in (".bas", ".bi"):
            keywords = r"\b(PRINT|INPUT|LET|DIM|AS|INTEGER|STRING|SINGLE|DOUBLE|IF|THEN|ELSE|END|FOR|TO|STEP|NEXT|DO|LOOP|WHILE|WEND|GOTO|GOSUB|RETURN|FUNCTION|SUB|SELECT|CASE|AND|OR|NOT|MOD|TRUE|FALSE|SLEEP|CLS|SCREEN|DATA|READ|RESTORE|CONST|TYPE|REDIM|PRESERVE|EXIT|DECLARE)\b"
            comments = r"'.*|REM.*"
        elif ext in (".php", ".phtml"):
            keywords = r"\b(abstract|and|array|as|break|callable|case|catch|class|clone|const|continue|declare|default|do|echo|else|elseif|empty|endfor|endforeach|endif|endswitch|endwhile|eval|exit|extends|final|finally|for|foreach|function|global|if|implements|include|include_once|instanceof|interface|isset|list|namespace|new|or|print|private|protected|public|require|require_once|return|static|switch|throw|trait|try|unset|use|var|while|xor|yield|true|false|null|match|fn)\b"
            comments = r"//.*|#.*|/\*[\s\S]*?\*/"
        elif ext == ".lua":
            keywords = r"\b(and|break|do|else|elseif|end|false|for|function|if|in|local|nil|not|or|repeat|return|then|true|until|while)\b"
            comments = r"--.*|--\[\[[\s\S]*?\]\]"
        elif ext in (".py",):
            keywords = r"\b(and|as|assert|async|await|break|class|continue|def|del|elif|else|except|False|finally|for|from|global|if|import|in|is|lambda|None|nonlocal|not|or|pass|raise|return|True|try|while|with|yield|match|case)\b"
            comments = r"#.*"
        elif ext in (".js", ".mjs", ".cjs", ".ts"):
            keywords = r"\b(async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|export|extends|false|finally|for|from|function|if|import|in|instanceof|let|new|null|return|static|super|switch|this|throw|true|try|typeof|undefined|var|void|while|yield|interface|type|enum|implements|public|private|protected|readonly|unknown|never|string|number|boolean)\b"
            comments = r"//.*|/\*[\s\S]*?\*/"
        elif ext in (".rb",):
            keywords = r"\b(BEGIN|END|alias|and|begin|break|case|class|def|defined|do|else|elsif|end|ensure|false|for|if|in|module|next|nil|not|or|redo|rescue|retry|return|self|super|then|true|undef|unless|until|when|while|yield)\b"
            comments = r"#.*"
        elif ext in (".kt", ".kts"):
            keywords = r"\b(as|break|class|continue|do|else|false|for|fun|if|in|interface|is|null|object|package|return|super|this|throw|true|try|typealias|val|var|when|while|by|catch|finally|import|private|public|protected|internal|override|suspend|data|enum|sealed|companion)\b"
            comments = r"//.*|/\*[\s\S]*?\*/"
        elif ext in (".luau", ".lua"):
            keywords = r"\b(and|break|do|else|elseif|end|false|for|function|if|in|local|nil|not|or|repeat|return|then|true|until|while|continue|export|type|typeof)\b"
            comments = r"--.*|--\[\[[\s\S]*?\]\]"
        elif ext == ".sql":
            keywords = r"\b(SELECT|FROM|WHERE|INSERT|INTO|VALUES|UPDATE|SET|DELETE|CREATE|TABLE|ALTER|DROP|JOIN|INNER|LEFT|RIGHT|ON|GROUP|BY|ORDER|HAVING|LIMIT|DISTINCT|AS|AND|OR|NOT|NULL|PRIMARY|KEY|FOREIGN|REFERENCES|COUNT|SUM|AVG|MIN|MAX|BEGIN|COMMIT|ROLLBACK)\b"
            comments = r"--.*|/\*[\s\S]*?\*/"
        elif ext == ".ino":
            keywords = r"\b(void|setup|loop|pinMode|digitalWrite|digitalRead|analogRead|analogWrite|delay|millis|Serial|begin|print|println|HIGH|LOW|INPUT|OUTPUT|INPUT_PULLUP|if|else|for|while|return|const|int|long|bool|true|false)\b"
            comments = r"//.*|/\*[\s\S]*?\*/"
        else:
            keywords = r"\b(if|else|for|while|return|class|function|local|end|true|false|nil)\b"
            comments = r"//.*|#.*|--.*"
        for match in re.finditer(keywords, text):
            self.editor.tag_add("keyword", f"1.0+{match.start()}c", f"1.0+{match.end()}c")
        for match in re.finditer(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', text):
            self.editor.tag_add("string", f"1.0+{match.start()}c", f"1.0+{match.end()}c")
        for match in re.finditer(comments, text):
            self.editor.tag_add("comment", f"1.0+{match.start()}c", f"1.0+{match.end()}c")
        for match in re.finditer(r"\b\d+(?:\.\d+)?\b", text):
            self.editor.tag_add("number", f"1.0+{match.start()}c", f"1.0+{match.end()}c")
        self.editor.tag_config("keyword", foreground="#1464b4")
        self.editor.tag_config("string", foreground="#22863a")
        self.editor.tag_config("comment", foreground="#6a737d")
        self.editor.tag_config("number", foreground="#b35c00")

    def apply_custom_theme(self, theme):
        defaults = {"background": "white", "foreground": "#202124", "cursor": "#202124",
                    "gutter_background": "#f1f3f4", "gutter_foreground": "#666666",
                    "console_background": "white", "console_foreground": "#202124"}
        defaults.update(theme)
        self.editor.configure(background=defaults["background"], foreground=defaults["foreground"], insertbackground=defaults["cursor"])
        self.line_numbers.configure(background=defaults["gutter_background"], foreground=defaults["gutter_foreground"])
        self.console.configure(background="#1e1e1e", foreground="#d4d4d4", insertbackground="#ffffff", selectbackground="#264f78")
        self.mod_manager.settings["theme"] = "custom"
        self.mod_manager.save()
        self.highlight_syntax()

    def _load_declarative_theme(self, mod):
        theme_path = mod["path"] / "theme.json"
        if not theme_path.exists():
            return False
        theme = read_json(theme_path, None)
        if not isinstance(theme, dict):
            raise ValueError(f"theme.json inválido no mod {mod['manifest'].get('name')}.")
        self.apply_custom_theme(theme)
        return True

    def load_enabled_mods(self, startup=False):
        # Reset to the base theme before applying currently enabled theme mods.
        self.apply_theme()
        self.mod_commands = []
        self.loaded_mods = {}
        errors = []
        for mod in self.mod_manager.refresh():
            if not mod["enabled"]:
                continue
            manifest, folder = mod["manifest"], mod["path"]
            mod_id = manifest["id"]
            try:
                self._load_declarative_theme(mod)
                entry = folder / "mod.py"
                if entry.exists() and mod_id in self.mod_manager.settings.get("trusted", []):
                    module_name = "forja_mod_" + re.sub(r"[^A-Za-z0-9_]", "_", mod_id)
                    spec = importlib.util.spec_from_file_location(module_name, entry)
                    if not spec or not spec.loader:
                        raise RuntimeError("Não foi possível carregar mod.py")
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    api = ForjaModAPI(self, mod_id)
                    if callable(getattr(module, "register", None)):
                        module.register(api)
                    elif callable(getattr(module, "main", None)):
                        module.main(api)
                    else:
                        raise ValueError("mod.py precisa definir register(api) ou main(api).")
                    self.loaded_mods[mod_id] = module
            except Exception as exc:
                errors.append(f"{manifest.get('name', mod_id)}: {exc}")
        self._refresh_mod_command_menu()
        if errors and not startup:
            messagebox.showwarning("Mods", "Alguns mods não carregaram:\n\n" + "\n".join(errors), parent=self)
        elif errors:
            self.status.set(f"Falha ao carregar {len(errors)} mod(s); veja a aba Mods.")

    def reload_mods(self):
        self.load_enabled_mods(startup=False)
        self.status.set(f"Mods recarregados. Comandos disponíveis: {len(self.mod_commands)}")

    def _refresh_mod_command_menu(self):
        if not hasattr(self, "mods_commands_menu"):
            return
        self.mods_commands_menu.delete(0, "end")
        if not self.mod_commands:
            self.mods_commands_menu.add_command(label="Nenhum comando registrado", state="disabled")
            return
        for item in self.mod_commands:
            self.mods_commands_menu.add_command(
                label=f"{item['label']}  [{item['mod_id']} ]",
                command=lambda cmd=item: self._run_mod_command(cmd)
            )

    def _run_mod_command(self, item):
        try:
            item["callback"]()
        except Exception as exc:
            messagebox.showerror("Erro em comando de mod", f"{item['label']}:\n{exc}", parent=self)

    def show_mod_commands(self):
        if not self.mod_commands:
            messagebox.showinfo("Comandos dos mods", "Nenhum comando registrado. Ative um mod compatível e recarregue os mods.", parent=self)
            return
        win = tk.Toplevel(self)
        win.title("Comandos dos Mods — Forja IDE")
        win.geometry("480x360")
        ttk.Label(win, text="Escolha um comando registrado pelos mods ativos.").pack(anchor="w", padx=10, pady=8)
        tree = ttk.Treeview(win, columns=("mod",), show="tree headings", height=12)
        tree.heading("#0", text="Comando")
        tree.heading("mod", text="Mod")
        tree.column("#0", width=270)
        tree.column("mod", width=150)
        tree.pack(fill="both", expand=True, padx=10, pady=5)
        for i, item in enumerate(self.mod_commands):
            tree.insert("", "end", iid=str(i), text=item["label"], values=(item["mod_id"],))
        def run_selected():
            selected = tree.selection()
            if selected:
                self._run_mod_command(self.mod_commands[int(selected[0])])
        ttk.Button(win, text="Executar comando", command=run_selected).pack(anchor="e", padx=10, pady=8)

    def show_welcome(self):
        """Show the welcome screen when no file is currently open."""
        if hasattr(self, "welcome_tab"):
            self.notebook.select(self.welcome_tab)

    def show_editor(self):
        """Show the editor after creating or opening a file."""
        if hasattr(self, "editor_tab"):
            self.notebook.select(self.editor_tab)

    def apply_theme(self):
        theme = self.mod_manager.settings.get("theme", "default")
        if theme == "dark":
            bg, fg, insert = "#202124", "#e8eaed", "#ffffff"
            self.editor.configure(background=bg, foreground=fg, insertbackground=insert)
            self.line_numbers.configure(background="#292a2d", foreground="#aeb3b8")
        else:
            self.editor.configure(background="white", foreground="#202124", insertbackground="#202124")
            self.line_numbers.configure(background="#f1f3f4", foreground="#666666")
        # O terminal mantém o estilo escuro semelhante ao terminal integrado do VS Code,
        # independentemente do tema escolhido para o editor.
        self.console.configure(background="#1e1e1e", foreground="#d4d4d4", insertbackground="#ffffff", selectbackground="#264f78")
        self.highlight_syntax()

    def on_language_change(self, event=None):
        language = self.selected_language.get()
        self.status.set(f"Linguagem selecionada: {language}")
        if self.current_file is None:
            self.title(f"{APP_NAME} {APP_VERSION} - Novo arquivo ({language})")
        self.highlight_syntax()
        self.save_session_config()

    def suggested_extension(self):
        return {"C": ".c", "C++": ".cpp", "C#": ".cs", "Java": ".java", "JavaScript": ".js", "TypeScript": ".ts", "Python": ".py", "Go": ".go", "Rust": ".rs", "Kotlin": ".kt", "Ruby": ".rb", "Lua": ".lua", "Luau": ".luau", "FreeBASIC": ".bas", "PHP": ".php", "SQL": ".sql", "Arduino": ".ino"}.get(self.selected_language.get(), ".c")

    def new_file(self):
        if not self.confirm_discard():
            return
        self.editor.delete("1.0", "end")
        self.current_file = None
        self.show_editor()
        self.editor.focus_set()
        language = self.selected_language.get()
        self.title(f"{APP_NAME} {APP_VERSION} - Novo arquivo ({language})")
        self.update_line_numbers()
        self.save_session_config()

    def confirm_discard(self):
        return True  # Simple editor: does not track unsaved changes yet.

    def open_file(self):
        path = filedialog.askopenfilename(filetypes=[("Arquivos de código", "*.c *.h *.cpp *.cc *.cxx *.hpp *.cs *.java *.js *.mjs *.cjs *.py *.go *.rs *.lua *.bas *.bi *.php *.phtml *.ts *.kt *.kts *.rb *.luau *.sql *.ino *.txt"), ("Todos os arquivos", "*.*")])
        if not path:
            return
        try:
            content = Path(path).read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            messagebox.showerror("Abrir arquivo", f"Não foi possível abrir o arquivo:\n{exc}")
            return
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", content)
        self.current_file = Path(path)
        self.sync_language_to_file()
        self.refresh_sidebar_tree()
        self.title(f"{APP_NAME} {APP_VERSION} - {self.current_file.name}")
        self.update_line_numbers()
        self.refresh_sidebar_tree()
        self.show_editor()
        self.status.set(f"Arquivo aberto: {self.current_file.name}")
        self.save_session_config()

    def sync_language_to_file(self):
        if not self.current_file:
            return
        ext = self.current_file.suffix.lower()
        mapping = {".c": "C", ".h": "C", ".cpp": "C++", ".cc": "C++", ".cxx": "C++", ".hpp": "C++", ".cs": "C#", ".java": "Java", ".js": "JavaScript", ".mjs": "JavaScript", ".cjs": "JavaScript", ".ts": "TypeScript", ".py": "Python", ".go": "Go", ".rs": "Rust", ".kt": "Kotlin", ".kts": "Kotlin", ".rb": "Ruby", ".lua": "Lua", ".luau": "Luau", ".bas": "FreeBASIC", ".bi": "FreeBASIC", ".php": "PHP", ".phtml": "PHP", ".ts": "TypeScript", ".kt": "Kotlin", ".kts": "Kotlin", ".rb": "Ruby", ".luau": "Luau", ".sql": "SQL", ".ino": "Arduino"}
        if ext in mapping:
            self.selected_language.set(mapping[ext])
            self.status.set(f"Linguagem do arquivo: {mapping[ext]}")

    def save_file(self):
        if self.current_file is None:
            return self.save_as()
        try:
            self.current_file.write_text(self.editor.get("1.0", "end-1c"), encoding="utf-8")
            self.status.set(f"Salvo: {self.current_file.name}")
            self.refresh_sidebar_tree()
            self.save_session_config()
            return True
        except OSError as exc:
            messagebox.showerror("Salvar", str(exc))
            return False

    def save_as(self):
        ext = self.suggested_extension()
        initial = {"C": "main.c", "C++": "main.cpp", "C#": "Program.cs", "Java": "Main.java", "JavaScript": "main.js", "Python": "main.py", "Go": "main.go", "Rust": "main.rs", "Lua": "main.lua", "FreeBASIC": "main.bas", "PHP": "index.php", "TypeScript": "main.ts", "Kotlin": "Main.kt", "Ruby": "main.rb", "Luau": "main.luau", "SQL": "query.sql", "Arduino": "sketch.ino"}.get(self.selected_language.get(), "main.c")
        path = filedialog.asksaveasfilename(
            defaultextension=ext, initialfile=initial,
            filetypes=[("C", "*.c"), ("C++", "*.cpp"), ("C#", "*.cs"), ("Java", "*.java"), ("JavaScript", "*.js"), ("Python", "*.py"), ("Go", "*.go"), ("Rust", "*.rs"), ("Lua", "*.lua"), ("FreeBASIC", "*.bas"), ("PHP", "*.php"), ("TypeScript", "*.ts"), ("Kotlin", "*.kt"), ("Ruby", "*.rb"), ("Luau", "*.luau"), ("SQL", "*.sql"), ("Arduino", "*.ino"), ("Todos", "*.*")]
        )
        if not path:
            return False
        self.current_file = Path(path)
        self.sync_language_to_file()
        self.refresh_sidebar_tree()
        self.title(f"{APP_NAME} {APP_VERSION} - {self.current_file.name}")
        return self.save_file()

    def auto_indent(self, event=None):
        line = self.editor.get("insert linestart", "insert")
        indent = re.match(r"\s*", line).group(0)
        self.editor.insert("insert", "\n" + indent)
        self.update_line_numbers()
        return "break"

    def insert_tab(self, event=None):
        self.editor.insert("insert", "    ")
        return "break"

    def on_editor_keypress(self, event):
        # Hide suggestions when navigating or accepting a completion.
        if event.keysym in ("Escape", "Return", "Tab", "Left", "Right", "Up", "Down"):
            self.hide_completion_popup()

    def on_editor_keyrelease(self, event=None):
        self.update_line_numbers()
        if event and (event.char.isalnum() or event.char in "_ .") and not (event.state & 0x4):
            self.show_completions()
        elif event and event.keysym not in ("Shift_L", "Shift_R", "Control_L", "Control_R"):
            self.hide_completion_popup()

    def _completion_words(self):
        lang = self.selected_language.get()
        common = {
            "Python": "print input len range str int float list dict set tuple open enumerate zip map filter sorted sum min max abs round type isinstance isinstance def class return yield lambda import from as if elif else for while break continue try except finally raise with pass True False None and or not self super __init__ __name__ append extend items keys values get split join replace format read write close json pathlib os sys math random", 
            "JavaScript": "console.log console.error console.warn function const let var return if else for while break continue class constructor new this import export from async await try catch finally throw Promise Array Object JSON Math Date setTimeout fetch map filter reduce push pop length stringify parse undefined null true false",
            "C": "#include int main void char double float long short unsigned signed printf scanf return if else for while do switch case break continue struct typedef const static sizeof NULL",
            "C++": "#include int main void char double float long short unsigned signed std::cout std::cin std::string std::vector std::map std::endl cout cin return if else for while class public private protected virtual override const auto namespace using nullptr",
            "C#": "using System Console.WriteLine Console.ReadLine string int double float bool class static void Main public private return if else for foreach while new var async await Task List Dictionary namespace",
            "Java": "public private protected static void main String System.out.println Scanner class new return if else for while try catch finally import package int double boolean ArrayList List",
            "Go": "package main import fmt.Println fmt.Printf func main var const int string bool if else for range return defer go chan make len append error",
            "Rust": "fn main let mut println! print! String Vec Option Result Some None Ok Err match if else for while loop pub mod use struct enum impl trait mut self return",
            "Lua": "local function print io.write pairs ipairs table string math if then elseif else end for while do repeat until return nil true false",
            "PHP": "<?php ?> echo print function return if else elseif endif for foreach as while do switch case break continue class public private protected static new extends implements interface trait namespace use require include require_once include_once true false null array string int float bool mixed void self parent this isset empty count strlen explode implode json_encode json_decode file_get_contents",
            "Ruby": "puts print p def end class module require include attr_reader attr_writer attr_accessor if elsif else unless case when while until do each map select collect return yield self nil true false and or not begin rescue ensure raise",
            "SQL": "SELECT FROM WHERE INSERT INTO VALUES UPDATE SET DELETE CREATE TABLE ALTER DROP JOIN INNER LEFT RIGHT ON GROUP BY ORDER HAVING LIMIT DISTINCT AS AND OR NOT NULL PRIMARY KEY FOREIGN REFERENCES COUNT SUM AVG MIN MAX",
            "Luau": "local function print warn if then elseif else end for while repeat until do break return true false nil and or not game workspace script require task wait spawn pairs ipairs type typeof tostring tonumber table string math Vector3 CFrame Instance",
            "Kotlin": "fun main val var println print class data object interface companion override open private public internal protected suspend return if else when for while do try catch finally throw null true false is as in import package List MutableList mapOf listOf",
            "TypeScript": "const let var function return if else for while class interface type enum public private protected readonly async await Promise string number boolean any unknown never void null undefined true false import export from default console.log",
            "Arduino": "void setup loop pinMode digitalWrite digitalRead analogRead analogWrite delay millis Serial begin print println HIGH LOW INPUT OUTPUT INPUT_PULLUP",
        }
        words = common.get(lang, "")
        try:
            existing = re.findall(r"[A-Za-z_][A-Za-z0-9_]*", self.editor.get("1.0", "end-1c"))
            words += " " + " ".join(existing)
        except Exception:
            pass
        return sorted(set(words.split()), key=str.lower)

    def show_completions(self):
        try:
            prefix = self.editor.get("insert wordstart", "insert")
        except tk.TclError:
            return
        if len(prefix) < 2:
            self.hide_completion_popup()
            return
        matches = [w for w in self._completion_words() if w.lower().startswith(prefix.lower()) and w != prefix]
        matches = matches[:10]
        if not matches:
            self.hide_completion_popup()
            return
        if self.completion_popup is None or not self.completion_popup.winfo_exists():
            self.completion_popup = tk.Toplevel(self)
            self.completion_popup.wm_overrideredirect(True)
            self.completion_list = tk.Listbox(self.completion_popup, height=min(8, len(matches)), width=28, font=("Consolas", 10), activestyle="dotbox")
            self.completion_list.pack()
            self.completion_list.bind("<Double-Button-1>", self.accept_completion)
            self.completion_list.bind("<Return>", self.accept_completion)
            self.completion_list.bind("<Escape>", lambda e: self.hide_completion_popup())
        self.completion_list.delete(0, "end")
        for word in matches:
            self.completion_list.insert("end", word)
        self.completion_list.selection_set(0)
        bbox = self.editor.bbox("insert")
        if bbox:
            x, y, _, h = bbox
            self.completion_popup.geometry(f"+{self.editor.winfo_rootx()+x}+{self.editor.winfo_rooty()+y+h+2}")
            self.completion_popup.deiconify()
            self.completion_popup.lift()

    def accept_completion(self, event=None):
        if not self.completion_list or not self.completion_list.curselection():
            return "break"
        word = self.completion_list.get(self.completion_list.curselection()[0])
        start = self.editor.index("insert wordstart")
        self.editor.delete(start, "insert")
        self.editor.insert(start, word)
        self.hide_completion_popup()
        self.editor.focus_set()
        return "break"

    def hide_completion_popup(self):
        if self.completion_popup is not None:
            try:
                self.completion_popup.withdraw()
            except tk.TclError:
                pass

    def autocomplete(self, event=None):
        self.show_completions()
        snippets = {
            "C: main": "int main(void) {\n    \n    return 0;\n}",
            "C: printf": 'printf("%s\\n", );',
            "Java: main": "public static void main(String[] args) {\n    \n}",
            "Lua: function": "function nome()\n    \nend",
            "Lua: local": "local nome = ",
            "Python: main": "def main():\n    print(\"Olá, mundo!\")\n\nif __name__ == \"__main__\":\n    main()",
            "JavaScript: console.log": "console.log(\"Olá, mundo!\");",
            "C++: main": "#include <iostream>\n\nint main() {\n    std::cout << \"Olá, mundo!\" << std::endl;\n    return 0;\n}",
            "C#: main": "using System;\n\nConsole.WriteLine(\"Olá, mundo!\");",
            "Go: main": "package main\n\nimport \"fmt\"\n\nfunc main() {\n    fmt.Println(\"Olá, mundo!\")\n}",
            "Rust: main": "fn main() {\n    println!(\"Olá, mundo!\");\n}",
        }
        choice = simpledialog.askstring("Modelos de código", "Digite uma opção:\n" + "\n".join(snippets), parent=self)
        if choice in snippets:
            self.editor.insert("insert", snippets[choice])
        return "break"

    def _terminal_prompt_text(self):
        folder = self.current_file.parent if self.current_file else (self.mod_project_dir or ROOT)
        # Mostra um caminho curto, como a linha de comando do terminal do VS Code.
        return f"PS {folder}>" if os.name == "nt" else f"$ {folder}"

    def _console_write(self, text):
        """Thread-safe output: background reader threads schedule UI updates on Tk."""
        if threading.current_thread() is not threading.main_thread():
            try:
                self.after(0, self._console_write, text)
            except tk.TclError:
                pass
            return
        try:
            self.console.configure(state="normal")
            self.console.insert("end", text)
            self.console.see("end")
            self.console.configure(state="disabled")
        except tk.TclError:
            pass

    def clear_terminal(self):
        self.console.configure(state="normal")
        self.console.delete("1.0", "end")
        self.console.configure(state="disabled")
        self.console_input.focus_set()

    def _terminal_cwd(self):
        if self.current_file:
            return self.current_file.parent
        if self.mod_project_dir:
            return self.mod_project_dir
        return ROOT

    def run_terminal_command(self, command_text):
        command_text = command_text.strip()
        if not command_text:
            return
        if self.process and self.process.poll() is None:
            self._console_write("\n[Forja] Um programa está em execução; a entrada foi encaminhada para ele. Pare-o para executar comandos do terminal.\n")
            return
        cwd = self._terminal_cwd()
        self._console_write(f"\n{self._terminal_prompt_text()} {command_text}\n")
        try:
            # shell=True é intencional: este campo funciona como terminal de comandos.
            self.process = subprocess.Popen(
                command_text, cwd=str(cwd), shell=True, stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                encoding="utf-8", errors="replace", bufsize=1
            )
        except (OSError, ValueError) as exc:
            self._console_write(f"Erro ao iniciar comando: {exc}\n")
            return
        threading.Thread(target=self._read_process_output, args=(self.process,), daemon=True).start()
        self.status.set("Comando do terminal em execução")

    def run_code(self):
        if self.process and self.process.poll() is None:
            messagebox.showinfo("Executar", "Já existe um programa em execução. Pare-o antes de iniciar outro.")
            return
        if self.current_file is None:
            if not self.save_as():
                return
        elif not self.save_file():
            return
        path = self.current_file
        ext = path.suffix.lower()
        command = None
        try:
            if ext == ".c":
                compiler = shutil.which("gcc") or shutil.which("clang")
                if not compiler:
                    raise RuntimeError("Compilador C não encontrado. Instale GCC/MinGW-w64 ou Clang e adicione-o ao PATH.")
                exe = path.with_suffix(".exe" if os.name == "nt" else "")
                result = subprocess.run([compiler, str(path), "-o", str(exe)], capture_output=True, text=True, timeout=60, cwd=str(path.parent))
                if result.returncode:
                    self._console_write(result.stdout + result.stderr + "\n")
                    self.notebook.select(1)
                    return
                command = [str(exe)]
            elif ext in (".cpp", ".cc", ".cxx", ".hpp"):
                compiler = shutil.which("g++") or shutil.which("clang++")
                if not compiler:
                    raise RuntimeError("Compilador C++ não encontrado. Instale MinGW-w64 (g++) ou Clang e adicione-o ao PATH.")
                exe = path.with_suffix(".exe" if os.name == "nt" else "")
                result = subprocess.run([compiler, "-std=c++17", str(path), "-o", str(exe)], capture_output=True, text=True, timeout=90, cwd=str(path.parent))
                if result.returncode:
                    self._console_write(result.stdout + result.stderr + "\n")
                    self.notebook.select(1)
                    return
                command = [str(exe)]
            elif ext == ".java":
                java, javac = shutil.which("java"), shutil.which("javac")
                if not java or not javac:
                    raise RuntimeError("Java não encontrado. Instale um JDK e adicione java/javac ao PATH.")
                result = subprocess.run([javac, str(path)], capture_output=True, text=True, timeout=60, cwd=str(path.parent))
                if result.returncode:
                    self._console_write(result.stdout + result.stderr + "\n")
                    self.notebook.select(1)
                    return
                command = [java, "-cp", str(path.parent), path.stem]
            elif ext in (".js", ".mjs", ".cjs"):
                node = shutil.which("node")
                if not node:
                    raise RuntimeError("Node.js não encontrado. Instale Node.js e adicione node ao PATH.")
                command = [node, str(path)]
            elif ext == ".py":
                if not getattr(sys, "frozen", False):
                    command = [sys.executable, str(path)]
                else:
                    python = shutil.which("python") or shutil.which("python3")
                    py_launcher = shutil.which("py") if os.name == "nt" else None
                    if python:
                        command = [python, str(path)]
                    elif py_launcher:
                        command = [py_launcher, "-3", str(path)]
                    else:
                        raise RuntimeError("Interpretador Python não encontrado. Instale Python 3 e adicione-o ao PATH.")
            elif ext == ".go":
                go = shutil.which("go")
                if not go:
                    raise RuntimeError("Go não encontrado. Instale o Go e adicione go ao PATH.")
                command = [go, "run", str(path)]
            elif ext == ".rs":
                rustc = shutil.which("rustc")
                if not rustc:
                    raise RuntimeError("Rust não encontrado. Instale Rust via rustup e adicione rustc ao PATH.")
                exe = path.with_suffix(".exe" if os.name == "nt" else "")
                result = subprocess.run([rustc, str(path), "-o", str(exe)], capture_output=True, text=True, timeout=90, cwd=str(path.parent))
                if result.returncode:
                    self._console_write(result.stdout + result.stderr + "\n")
                    self.notebook.select(1)
                    return
                command = [str(exe)]
            elif ext == ".cs":
                dotnet = shutil.which("dotnet")
                if not dotnet:
                    raise RuntimeError(".NET SDK não encontrado. Instale o SDK do .NET e adicione dotnet ao PATH.")
                # Build in Forja's cache, keeping generated project files out of the user's source folder.
                build_dir = Path(tempfile.mkdtemp(prefix="csharp_", dir=str(CACHE_DIR)))
                sdk_result = subprocess.run([dotnet, "--list-sdks"], capture_output=True, text=True, timeout=15)
                versions = re.findall(r"^(\d+)\.\d+\.\d+", sdk_result.stdout, re.M)
                major = max((int(v) for v in versions), default=8)
                target = f"net{major}.0"
                (build_dir / "Program.cs").write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
                project_name = "ForjaCSharp"
                (build_dir / f"{project_name}.csproj").write_text(
                    "<Project Sdk=\"Microsoft.NET.Sdk\"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>" + target + "</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable></PropertyGroup></Project>", encoding="utf-8")
                result = subprocess.run([dotnet, "build", str(build_dir / f"{project_name}.csproj"), "--nologo", "-o", str(build_dir / "out")], capture_output=True, text=True, timeout=180, cwd=str(build_dir))
                if result.returncode:
                    self._console_write(result.stdout + result.stderr + "\n")
                    self.notebook.select(1)
                    return
                command = [dotnet, str(build_dir / "out" / f"{project_name}.dll")]
            elif ext == ".rb":
                ruby = shutil.which("ruby")
                if not ruby:
                    raise RuntimeError("Ruby não encontrado. Instale Ruby para Windows e adicione ruby.exe ao PATH: https://rubyinstaller.org/")
                command = [ruby, str(path)]
            elif ext == ".luau":
                luau = shutil.which("luau")
                if not luau:
                    raise RuntimeError("Interpretador Luau não encontrado. Instale a CLI Luau e adicione luau.exe ao PATH: https://luau.org/")
                command = [luau, str(path)]
            elif ext in (".ts",):
                node = shutil.which("node")
                tsx = shutil.which("tsx")
                if not node:
                    raise RuntimeError("Node.js não encontrado. Instale Node.js primeiro: https://nodejs.org/")
                if tsx:
                    command = [tsx, str(path)]
                else:
                    tsc = shutil.which("tsc")
                    if not tsc:
                        raise RuntimeError("TypeScript não encontrado. Instale com `npm install -g typescript tsx` no terminal.")
                    ts_build = CACHE_DIR / "typescript_build" / path.stem
                    ts_build.mkdir(parents=True, exist_ok=True)
                    js_out = ts_build / (path.stem + ".js")
                    result = subprocess.run([tsc, str(path), "--target", "ES2020", "--module", "commonjs", "--skipLibCheck", "--outDir", str(ts_build)], capture_output=True, text=True, timeout=90, cwd=str(path.parent))
                    if result.returncode:
                        self._console_write(result.stdout + result.stderr + "\n")
                        self.notebook.select(1)
                        return
                    command = [node, str(js_out)]
            elif ext in (".kt", ".kts"):
                kotlinc = shutil.which("kotlinc")
                java = shutil.which("java")
                if not kotlinc or not java:
                    raise RuntimeError("Kotlin/JVM não encontrado. Instale Kotlin e um JDK, e adicione kotlinc/java ao PATH: https://kotlinlang.org/")
                jar = path.with_suffix(".forja.jar")
                result = subprocess.run([kotlinc, str(path), "-include-runtime", "-d", str(jar)], capture_output=True, text=True, timeout=120, cwd=str(path.parent))
                if result.returncode:
                    self._console_write(result.stdout + result.stderr + "\n")
                    self.notebook.select(1)
                    return
                command = [java, "-jar", str(jar)]
            elif ext == ".sql":
                # SQL runs against an in-memory SQLite database, avoiding changes to user files.
                import sqlite3
                sql_text = path.read_text(encoding="utf-8")
                conn = sqlite3.connect(":memory:")
                try:
                    cursor = conn.cursor()
                    for statement in (part.strip() for part in sql_text.split(";") if part.strip()):
                        cursor.execute(statement)
                        if cursor.description:
                            rows = cursor.fetchall()
                            columns = [d[0] for d in cursor.description]
                            self._console_write(" | ".join(columns) + "\n")
                            for row in rows:
                                self._console_write(" | ".join(str(v) for v in row) + "\n")
                    self._console_write("\n[SQL] Execução concluída (SQLite em memória).\n")
                except sqlite3.Error as exc:
                    self._console_write(f"Erro SQL: {exc}\n")
                finally:
                    conn.close()
                self.notebook.select(1)
                return
            elif ext == ".ino":
                raise RuntimeError("Para Arduino, use o botão Arduino (F7), que compila e transfere para a placa.")
            elif ext in (".php", ".phtml"):
                php = shutil.which("php")
                if not php:
                    raise RuntimeError("PHP não encontrado. Instale o PHP para Windows e adicione php.exe ao PATH. https://www.php.net/downloads.php")
                command = [php, str(path)]
            elif ext in (".bas", ".bi"):
                fbc = shutil.which("fbc")
                if not fbc:
                    raise RuntimeError("FreeBASIC não encontrado. Instale o compilador FreeBASIC (fbc) e adicione-o ao PATH. Consulte https://www.freebasic.net/")
                exe = path.with_suffix(".exe" if os.name == "nt" else "")
                result = subprocess.run([fbc, str(path), "-x", str(exe)], capture_output=True, text=True, timeout=90, cwd=str(path.parent))
                if result.returncode:
                    self._console_write(result.stdout + result.stderr + "\n")
                    self.notebook.select(1)
                    return
                command = [str(exe)]
            elif ext == ".lua":
                lua = shutil.which("lua") or shutil.which("lua54") or shutil.which("lua5.4")
                if not lua:
                    raise RuntimeError("Lua não encontrado. Instale Lua e adicione-o ao PATH.")
                command = [lua, str(path)]
            else:
                raise RuntimeError("Extensão não reconhecida. Selecione uma das linguagens disponíveis na lista do editor.")
        except subprocess.TimeoutExpired as exc:
            self._console_write(f"\nTempo limite excedido durante compilação: {exc}\n")
            self.notebook.select(1)
            return
        except (OSError, RuntimeError) as exc:
            messagebox.showerror("Executar programa", str(exc))
            return
        self.notebook.select(1)
        self._console_write(f"\n> {' '.join(command)}\n")
        try:
            self.process = subprocess.Popen(command, cwd=str(path.parent), stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
        except OSError as exc:
            messagebox.showerror("Execução", str(exc))
            return
        threading.Thread(target=self._read_process_output, args=(self.process,), daemon=True).start()
        self.status.set("Programa em execução")

    def upload_arduino(self):
        """Compile and upload the current .ino sketch using Arduino CLI (F7)."""
        cli = shutil.which("arduino-cli")
        if not cli:
            messagebox.showerror("Arduino", "Arduino CLI não encontrado. Instale o Arduino CLI e adicione arduino-cli.exe ao PATH.\nhttps://arduino.github.io/arduino-cli/latest/installation/")
            return
        if self.current_file is None or self.current_file.suffix.lower() != ".ino":
            messagebox.showinfo("Arduino", "Abra ou salve primeiro um sketch com extensão .ino. Selecione Arduino na lista de linguagens.")
            return
        if not self.save_file():
            return
        fqbn = simpledialog.askstring("Arduino — placa", "Identificador FQBN da placa (ex.: arduino:avr:uno):", initialvalue="arduino:avr:uno", parent=self)
        if not fqbn:
            return
        port = simpledialog.askstring("Arduino — porta", "Porta da placa (ex.: COM3 no Windows ou /dev/ttyACM0 no Linux):", parent=self)
        if not port:
            return
        sketch = self.current_file
        # Arduino CLI expects a folder whose name matches the .ino filename.
        staging = CACHE_DIR / "arduino_sketch" / sketch.stem
        staging.mkdir(parents=True, exist_ok=True)
        staged_ino = staging / (sketch.stem + ".ino")
        try:
            shutil.copy2(sketch, staged_ino)
        except OSError as exc:
            messagebox.showerror("Arduino", f"Não foi possível preparar o sketch: {exc}")
            return
        self.notebook.select(1)
        self._console_write(f"\n[Arduino] Compilando {sketch.name} para {fqbn}...\n")
        try:
            result = subprocess.run([cli, "compile", "--fqbn", fqbn, str(staging)], capture_output=True, text=True, timeout=240, cwd=str(sketch.parent))
        except (OSError, subprocess.TimeoutExpired) as exc:
            self._console_write(f"Erro na compilação Arduino: {exc}\n")
            return
        self._console_write(result.stdout + result.stderr + "\n")
        if result.returncode != 0:
            self._console_write("[Arduino] Compilação falhou; a placa não foi alterada.\n")
            return
        self._console_write(f"[Arduino] Compilação concluída. Transferindo para {port}...\n")
        try:
            upload = subprocess.run([cli, "upload", "-p", port, "--fqbn", fqbn, str(staging)], capture_output=True, text=True, timeout=240, cwd=str(sketch.parent))
        except (OSError, subprocess.TimeoutExpired) as exc:
            self._console_write(f"Erro ao transferir para a placa: {exc}\n")
            return
        self._console_write(upload.stdout + upload.stderr + "\n")
        if upload.returncode == 0:
            self.status.set("Arduino: compilado e transferido")
            self._console_write("[Arduino] Transferência concluída.\n")
        else:
            self._console_write("[Arduino] Falha na transferência. Confira a porta, cabo e drivers.\n")

    def debug_code(self):
        """Start the standard-library pdb debugger for Python files."""
        if self.selected_language.get() != "Python" and (not self.current_file or self.current_file.suffix.lower() != ".py"):
            messagebox.showinfo("Depurar", "A depuração integrada desta versão usa pdb para Python. Para outras linguagens, instale e configure o depurador correspondente.")
            return
        if self.process and self.process.poll() is None:
            messagebox.showinfo("Depurar", "Pare a execução atual antes de iniciar o depurador.")
            return
        if self.current_file is None:
            if not self.save_as():
                return
        elif not self.save_file():
            return
        python = sys.executable or shutil.which("python") or shutil.which("py")
        if not python:
            messagebox.showerror("Depurar", "Não encontrei o interpretador Python.")
            return
        command = [python, "-m", "pdb", str(self.current_file)]
        self.notebook.select(1)
        self._console_write("\n[Depurador pdb] Comandos: n=próxima linha, s=entrar, c=continuar, p variável, q=sair\n> " + " ".join(command) + "\n")
        try:
            self.process = subprocess.Popen(command, cwd=str(self.current_file.parent), stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
            threading.Thread(target=self._read_process_output, args=(self.process,), daemon=True).start()
            self.status.set("Depurador Python iniciado (pdb)")
        except OSError as exc:
            messagebox.showerror("Depurar", str(exc))

    def _read_process_output(self, process):
        """Read output in small chunks so prompts without a newline appear immediately.

        readline() waits for a newline, which hides prompts such as `Digite um número: `.
        Reading chunks lets the integrated terminal display those prompts before the user
        sends input, instead of showing the input on a line before the prompt.
        """
        try:
            stream = process.stdout
            while True:
                chunk = stream.read(1)
                if chunk == "":
                    break
                self.after(0, self._console_write, chunk)
            code = process.wait()
            self.after(0, lambda code=code: self.status.set(f"Programa encerrado (código {code})"))
        except Exception as exc:
            try:
                self.after(0, self._console_write, f"\nErro ao ler saída: {exc}\n")
            except tk.TclError:
                pass

    def send_input(self, event=None):
        value = self.console_input.get()
        self.console_input.delete(0, "end")
        if self.process and self.process.poll() is None and self.process.stdin:
            try:
                self.process.stdin.write(value + "\n")
                self.process.stdin.flush()
                # Mostra a entrada enviada, útil para input()/scanf()/ReadLine().
                self._console_write(value + "\n")
            except (OSError, BrokenPipeError, ValueError) as exc:
                self._console_write(f"Não foi possível enviar a entrada: {exc}\n")
        else:
            self.run_terminal_command(value)
        return "break"

    def stop_code(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            self.status.set("Solicitado encerramento do programa")
        else:
            self.status.set("Nenhum programa em execução")

    def install_mod_dialog(self):
        path = filedialog.askopenfilename(title="Instalar mod", filetypes=[("Mods do Forja", "*.forjamod"), ("Pacotes ZIP", "*.zip")])
        if not path:
            return
        try:
            if self.mod_manager.install_package(path):
                self.refresh_mod_list()
                messagebox.showinfo("Mods", "Mod instalado. Se ele contiver mod.py, revise o código antes de ativá-lo. Mods Python exigem confirmação de confiança para executar.")
        except Exception as exc:
            messagebox.showerror("Falha ao instalar mod", str(exc))

    def refresh_mod_list(self):
        self.mod_manager.refresh()
        if not hasattr(self, "mod_tree"):
            return
        for item in self.mod_tree.get_children():
            self.mod_tree.delete(item)
        for mod in self.mod_manager.mods:
            m = mod["manifest"]
            self.mod_tree.insert("", "end", iid=str(m["id"]), text=m["name"],
                                 values=("Ativo" if mod["enabled"] else "Desativado",
                                         m.get("type", "?"), m.get("version", "?"),
                                         m.get("description", "")))

    def selected_mod(self):
        selected = self.mod_tree.selection()
        if not selected:
            messagebox.showinfo("Mods", "Selecione um mod na lista.")
            return None
        mod_id = selected[0]
        return next((m for m in self.mod_manager.mods if m["manifest"]["id"] == mod_id), None)

    def toggle_selected_mod(self, enable):
        mod = self.selected_mod()
        if not mod:
            return
        try:
            entry = mod["path"] / "mod.py"
            trusted = self.mod_manager.settings.setdefault("trusted", [])
            mod_id = mod["manifest"]["id"]
            if enable and entry.exists() and mod_id not in trusted:
                if not messagebox.askyesno(
                    "Confiar e executar código do mod?",
                    f"O mod '{mod['manifest'].get('name')}' contém mod.py.\n\n"
                    "Ao ativá-lo, o código Python será executado dentro do Forja e poderá acessar arquivos, rede e outros recursos do seu usuário.\n\n"
                    "Só continue se você revisou o código e confia no autor. Deseja confiar neste mod?", parent=self
                ):
                    return
                trusted.append(mod_id)
                self.mod_manager.save()
            if not enable and mod_id in trusted:
                # Keep trust choice; disabling prevents loading until re-enabled.
                pass
            self.mod_manager.toggle(mod, enable)
            self.refresh_mod_list()
            self.load_enabled_mods(startup=False)
        except Exception as exc:
            messagebox.showerror("Mods", str(exc))

    def remove_selected_mod(self):
        mod = self.selected_mod()
        if not mod:
            return
        try:
            if self.mod_manager.remove(mod):
                self.refresh_mod_list()
        except Exception as exc:
            messagebox.showerror("Mods", str(exc))

    def show_mod_details(self):
        mod = self.selected_mod()
        if not mod:
            return
        m = mod["manifest"]
        details = (
            f"Nome: {m.get('name')}\nID: {m.get('id')}\nVersão: {m.get('version')}\n"
            f"Tipo: {m.get('type')}\nEstado: {'Ativo' if mod['enabled'] else 'Desativado'}\n"
            f"Autor: {m.get('author', 'Não informado')}\nDescrição: {m.get('description', 'Sem descrição')}\n"
            f"Permissões declaradas: {', '.join(m.get('permissions', [])) or 'Nenhuma'}\n\n"
            f"Arquivos: {', '.join(p.name for p in mod['path'].iterdir())}\n\n"
            "Suporte: theme.json (tema declarativo) e mod.py com register(api) para plugins Python. "
            "Código Python de terceiros pode acessar recursos do sistema; permissões declaradas não são uma sandbox."
        )
        messagebox.showinfo("Detalhes do mod", details)

    def configure_catalog(self):
        current = self.mod_manager.catalog_url()
        url = simpledialog.askstring("Catálogo da loja", "URL HTTPS de um catálogo JSON de mods:", initialvalue=current, parent=self)
        if url is None:
            return
        url = url.strip()
        if url and not url.lower().startswith("https://"):
            messagebox.showerror("Catálogo", "Use uma URL HTTPS.")
            return
        self.mod_manager.settings["catalog_url"] = url
        self.mod_manager.save()
        messagebox.showinfo("Catálogo", "Configuração salva. A URL precisa apontar para um catálogo compatível.")

    def open_store(self):
        win = tk.Toplevel(self)
        win.title("Loja de Mods — Forja IDE")
        win.geometry("760x480")
        top = ttk.Frame(win)
        top.pack(fill="x", padx=10, pady=10)
        ttk.Label(top, text="Catálogo online", font=("TkDefaultFont", 12, "bold")).pack(side="left")
        ttk.Button(top, text="Carregar catálogo", command=lambda: self.load_store_catalog(win, tree, status)).pack(side="right")
        tree = ttk.Treeview(win, columns=("version", "type", "description"), show="tree headings")
        tree.heading("#0", text="Mod")
        tree.heading("version", text="Versão")
        tree.heading("type", text="Tipo")
        tree.heading("description", text="Descrição")
        tree.column("#0", width=180)
        tree.column("version", width=80)
        tree.column("type", width=100)
        tree.column("description", width=340)
        tree.pack(fill="both", expand=True, padx=10, pady=5)
        status = tk.StringVar(value="Configure uma URL de catálogo HTTPS e carregue o catálogo.")
        ttk.Label(win, textvariable=status, wraplength=700).pack(fill="x", padx=10, pady=5)
        buttons = ttk.Frame(win)
        buttons.pack(fill="x", padx=10, pady=8)
        ttk.Button(buttons, text="Instalar mod selecionado", command=lambda: self.install_store_selected(win, tree, status)).pack(side="left")
        win._catalog_items = []
        win._catalog_tree = tree
        win._catalog_status = status

    def load_store_catalog(self, win, tree, status):
        status.set("Carregando catálogo...")
        def worker():
            try:
                items = self.mod_manager.fetch_catalog()
                self.after(0, lambda: self._populate_store(win, items, status))
            except Exception as exc:
                self.after(0, lambda: status.set(f"Não foi possível carregar o catálogo: {exc}"))
        threading.Thread(target=worker, daemon=True).start()

    def _populate_store(self, win, items, status):
        tree = win._catalog_tree
        for child in tree.get_children():
            tree.delete(child)
        win._catalog_items = []
        for item in items:
            if not isinstance(item, dict) or not item.get("id") or not item.get("name"):
                continue
            win._catalog_items.append(item)
            tree.insert("", "end", iid=str(len(win._catalog_items)-1), text=item["name"],
                        values=(item.get("version", "?"), item.get("type", "?"), item.get("description", "")))
        status.set(f"Catálogo carregado: {len(win._catalog_items)} mod(s).")

    def install_store_selected(self, win, tree, status):
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Loja", "Selecione um mod.")
            return
        item = win._catalog_items[int(selected[0])]
        if not messagebox.askyesno("Instalar da loja", f"Baixar '{item.get('name')}'?\n\nConfira a origem e as permissões antes de instalar."):
            return
        status.set("Baixando e validando pacote...")
        def worker():
            try:
                package = self.mod_manager.download_mod(item)
                self.after(0, lambda: self._install_downloaded(package, status))
            except Exception as exc:
                self.after(0, lambda: status.set(f"Falha no download: {exc}"))
        threading.Thread(target=worker, daemon=True).start()

    def _install_downloaded(self, package, status):
        try:
            if self.mod_manager.install_package(package):
                self.refresh_mod_list()
                status.set("Mod instalado. Código executável não foi iniciado.")
            else:
                status.set("Instalação cancelada.")
        except Exception as exc:
            status.set(f"Falha na validação/instalação: {exc}")

    def security_info(self):
        messagebox.showwarning(
            "Segurança dos Mods",
            "Instale mods somente de fontes em que confia. theme.json é carregado como configuração; mod.py é executado apenas depois de confirmar confiança no mod. "
            "Isso NÃO cria uma sandbox: código Python de terceiros poderá acessar recursos do seu usuário. Revise o código antes de confiar. "
            "A loja online ainda precisa de um catálogo confiável e de um processo de publicação/revisão."
        )

    def about(self):
        messagebox.showinfo("Sobre", f"{APP_NAME} {APP_VERSION}\nEditor leve para C, C++, C#, Java, JavaScript, TypeScript, Python, Go, Rust, Kotlin, Ruby, Lua, Luau, FreeBASIC, PHP, SQL e Arduino, com suporte a temas e plugins. Arduino F7 compila e transfere via Arduino CLI.\nPython + Tkinter.")

    def on_close(self):
        self.save_session_config()
        if self.process and self.process.poll() is None:
            if not messagebox.askyesno("Sair", "Há um programa em execução. Deseja encerrá-lo e sair?"):
                return
            self.stop_code()
        self.destroy()


if __name__ == "__main__":
    app = ForjaApp()
    app.mainloop()
