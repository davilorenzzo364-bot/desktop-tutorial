"""Exemplo de plugin Forja IDE 4.0. Leia o código antes de confiar nele."""

def register(api):
    def inserir_cabecalho():
        api.insert_text("/*\n * Meu programa\n * Criado com Forja IDE\n */\n\n")

    def contar_linhas():
        linhas = len(api.get_text().splitlines())
        api.show_message("Contagem de linhas", f"O editor contém {linhas} linha(s).")

    api.register_command("Inserir cabeçalho C", inserir_cabecalho)
    api.register_command("Contar linhas do editor", contar_linhas)
