@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 forja.py
) else (
    python forja.py
)
if errorlevel 1 (
    echo.
    echo O Forja nao conseguiu iniciar. Verifique se o Python 3 esta instalado.
    pause
)
