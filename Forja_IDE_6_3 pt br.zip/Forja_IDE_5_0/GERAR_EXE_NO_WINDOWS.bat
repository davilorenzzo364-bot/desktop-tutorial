@echo off
setlocal
cd /d "%~dp0"
title Gerador do executavel - Forja IDE 5.0
echo ==============================================
echo   Forja IDE 5.0 - Gerar EXE para Windows
echo ==============================================
echo.
where py >nul 2>nul
if errorlevel 1 (
  echo ERRO: Python 3 nao foi encontrado.
  echo Instale Python 3 para Windows em https://www.python.org/downloads/windows/
  echo Durante a instalacao, marque Add Python to PATH.
  pause
  exit /b 1
)
echo [1/4] Instalando/atualizando PyInstaller...
py -3 -m pip install --upgrade pyinstaller
if errorlevel 1 goto erro
echo.
echo [2/4] Gerando o executavel...
py -3 -m PyInstaller --noconfirm --clean --windowed --onedir --name ForjaIDE forja.py
if errorlevel 1 goto erro
echo.
echo [3/4] Preparando pastas de dados ao lado do EXE...
if not exist "dist\ForjaIDE\mods\installed" mkdir "dist\ForjaIDE\mods\installed"
if not exist "dist\ForjaIDE\mods\disabled" mkdir "dist\ForjaIDE\mods\disabled"
if not exist "dist\ForjaIDE\settings" mkdir "dist\ForjaIDE\settings"
if not exist "dist\ForjaIDE\cache" mkdir "dist\ForjaIDE\cache"
if exist "mods\installed\*" xcopy "mods\installed\*" "dist\ForjaIDE\mods\installed\" /E /I /Y >nul
if exist "mods\disabled\*" xcopy "mods\disabled\*" "dist\ForjaIDE\mods\disabled\" /E /I /Y >nul
if exist "settings\*" xcopy "settings\*" "dist\ForjaIDE\settings\" /E /I /Y >nul
if exist "exemplos_mods" xcopy "exemplos_mods" "dist\ForjaIDE\exemplos_mods\" /E /I /Y >nul
copy /Y "SDK_MODS.md" "dist\ForjaIDE\SDK_MODS.md" >nul
(
  echo Forja IDE 5.0 - versao executavel
  echo.
  echo Execute ForjaIDE.exe. Mantenha as pastas ao lado do executavel.
  echo C, C++, C#, Java, JavaScript, Python, Go, Rust e Lua precisam de seus compiladores/interpretes instalados separadamente.
  echo Os mods Python sao codigo executavel: instale apenas mods em que confia.
) > "dist\ForjaIDE\LEIA-ME.txt"
echo.
echo [4/4] Compactando a pasta pronta...
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Test-Path 'ForjaIDE_Windows10.zip') { Remove-Item 'ForjaIDE_Windows10.zip' -Force }; Compress-Archive -Path 'dist\ForjaIDE\*' -DestinationPath 'ForjaIDE_Windows10.zip' -Force"
if errorlevel 1 goto erro
echo.
echo CONCLUIDO: dist\ForjaIDE\ForjaIDE.exe
echo Pacote pronto: ForjaIDE_Windows10.zip
pause
exit /b 0
:erro
echo.
echo Ocorreu um erro durante a compilacao. Veja as mensagens acima.
pause
exit /b 1
