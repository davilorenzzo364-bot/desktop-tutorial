# SDK de Mods — Forja IDE 5.0

A versão 4.0 suporta dois tipos práticos de mod:

1. **Tema declarativo**: `mod.json` + `theme.json`. Não precisa de Python.
2. **Plugin Python**: `mod.json` + `mod.py`. Pode registrar comandos e interagir com o editor usando a API abaixo. O código Python roda com as permissões do usuário e NÃO fica isolado.

## Criar um mod

Crie uma pasta com `mod.json` na raiz. O campo `id` deve ser único e usar letras, números, ponto, hífen ou sublinhado. Compacte os arquivos diretamente na raiz do ZIP (não coloque a pasta externa como primeiro nível) e renomeie o arquivo para `.forjamod`. Instale pela aba **Mods**.

### Exemplo de manifesto

```json
{
  "id": "seunome.minhaferramenta",
  "name": "Minha Ferramenta",
  "version": "1.0.0",
  "api_version": 1,
  "min_forja_version": "4.1",
  "type": "plugin",
  "author": "Seu nome",
  "description": "O que o mod faz",
  "permissions": ["editor.read", "editor.write"]
}
```

`permissions` documenta o que o mod pretende fazer; não é uma barreira de segurança.

## Tema sem código

Coloque `theme.json` ao lado do manifesto. Chaves aceitas:

- `background`, `foreground`, `cursor`
- `gutter_background`, `gutter_foreground`
- `console_background`, `console_foreground`

Os valores são cores Tkinter, por exemplo `#171923`. Tema é aplicado quando o mod está ativo e os mods são carregados. Desativar ou remover o tema e recarregar os mods retorna ao tema-base, salvo se outro tema estiver ativo.

## Plugin Python

Crie `mod.py` com uma função `register(api)`. Exemplo:

```python
def register(api):
    def inserir():
        api.insert_text("Olá do meu mod!\n")

    api.register_command("Inserir saudação", inserir)
```

Métodos da API disponível:

- `api.register_command(nome, funcao)`: adiciona um comando em **Mods → Executar comando** e na janela **Comandos dos mods**.
- `api.insert_text(texto)`: insere texto na posição do cursor.
- `api.get_text()`: retorna o conteúdo atual do editor.
- `api.set_text(texto)`: substitui o conteúdo do editor.
- `api.show_message(titulo, mensagem)`: mostra uma caixa de mensagem.
- `api.set_theme(dicionario)`: aplica cores usando as mesmas chaves de `theme.json`.

Ao ativar um mod que contém `mod.py`, o Forja pergunta se você confia nele. Leia o código antes de aceitar. Código Python pode ler e alterar arquivos, usar a rede, iniciar processos e fazer outras ações com os privilégios do usuário. O Forja não fornece sandbox para plugins Python.

## Testar os exemplos incluídos

Na pasta `exemplos_mods`, instale `Tema_Noite.forjamod` para experimentar um tema sem código ou `Ferramentas_Basicas.forjamod` para testar comandos de plugin. Para o segundo, leia `mod.py` antes de autorizar a execução.

## Limites desta API

API versão 1. Plugins podem registrar comandos e acessar o editor/tema, mas ainda não podem adicionar painéis arbitrários, novas linguagens ou runners de compilação por uma API estável. Esses tipos estão listados no manifesto para compatibilidade futura, mas não ganham esses recursos automaticamente.
