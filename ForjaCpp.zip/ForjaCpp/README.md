# Forja C++

Uma IDE inicial em C++/Qt 6 para Windows 10 e Windows 11, com editor, explorador de arquivos e execução de C, Java, Python e Ruby usando ferramentas instaladas separadamente.

## Recursos nesta versão inicial
- Editor com abas, numeração de linhas e destaque básico de sintaxe.
- Abrir/salvar arquivos e abrir pasta de projeto.
- Execução por extensão: `.c`, `.java`, `.py`, `.rb`.
- Saída do programa em um painel inferior.
- Configuração dos executáveis por variáveis de ambiente/PATH: `gcc`, `javac`/`java`, `python` ou `py`, `ruby`.
- Atalho `F5` para executar o arquivo atual; `Ctrl+O`, `Ctrl+S`, `Ctrl+Shift+S`.

> Esta é uma base funcional para desenvolver a IDE, não uma cópia completa do VS Code. O terminal inferior mostra a saída do programa; ainda não é um terminal de shell interativo completo. A execução de programas depende dos compiladores/interpretadores instalados.

## Requisitos
- Windows 10 ou 11 (64 bits)
- Qt 6 com o componente **Widgets**
- CMake 3.21+
- Compilador C++ compatível com Qt (por exemplo, MinGW correspondente à instalação do Qt ou MSVC)
- Para executar projetos: GCC/Clang para C; JDK para Java; Python; Ruby.

## Compilar no Windows
1. Instale o Qt 6 usando o Qt Online Installer. Selecione Qt Widgets e um kit de compilador (MinGW ou MSVC) compatível.
2. Instale CMake.
3. Abra um terminal configurado para o kit escolhido.
4. Na pasta do projeto, execute:

```powershell
cmake -S . -B build
cmake --build build --config Release
```

O executável será criado dentro da pasta `build` (o caminho exato varia conforme o gerador usado).

Se o CMake não encontrar Qt6, configure `CMAKE_PREFIX_PATH` para a pasta de instalação do Qt, por exemplo:

```powershell
cmake -S . -B build -DCMAKE_PREFIX_PATH="C:/Qt/6.x.x/mingw_64"
```

Use o caminho real da sua instalação.

## Como usar
1. Abra o ForjaCpp.
2. Use **Arquivo > Abrir arquivo** ou **Projeto > Abrir pasta**.
3. Escreva o código e salve com a extensão correta.
4. Pressione **F5** para compilar/executar.
5. Leia a saída no painel inferior.

## Ferramentas reconhecidas
- C (`.c`): `gcc arquivo.c -o arquivo.exe`, depois executa o `.exe`.
- Java (`.java`): `javac arquivo.java`, depois `java -cp pasta NomeDaClasse`.
- Python (`.py`): tenta `python arquivo.py`, depois `py arquivo.py`.
- Ruby (`.rb`): `ruby arquivo.rb`.

O nome do arquivo Java deve corresponder à classe pública quando exigido pelo Java. A primeira versão usa o nome do arquivo como classe principal; projetos Java maiores podem exigir configuração adicional.

## Próximas melhorias recomendadas
Terminal realmente interativo, autocomplete, depurador, configuração visual dos caminhos, múltiplos arquivos por projeto, suporte a C++, empacotamento com Qt deployment e instalador.
