#pragma once
#include <QMainWindow>
#include <QProcess>

class QTabWidget;
class QTreeView;
class QFileSystemModel;
class QPlainTextEdit;
class QSplitter;
class CodeEditor;
class SyntaxHighlighter;

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
protected:
    void closeEvent(QCloseEvent *event) override;
private:
    struct Document { QString path; CodeEditor *editor; SyntaxHighlighter *highlighter; };
    QTabWidget *tabs;
    QTreeView *tree;
    QFileSystemModel *fileModel;
    QPlainTextEdit *output;
    QSplitter *splitter;
    QProcess *process;
    QString projectRoot;
    QList<Document> documents;
    Document *currentDocument();
    CodeEditor *createEditor(const QString &text = QString());
    void createMenus();
    void openFile(const QString &path = QString());
    void saveFile(bool saveAs = false);
    void openFolder();
    void runCurrent();
    void appendOutput(const QString &text);
    QString findTool(const QStringList &candidates) const;
    void setTheme();
};
