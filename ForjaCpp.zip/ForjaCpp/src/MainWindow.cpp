#include "MainWindow.h"
#include "CodeEditor.h"
#include "SyntaxHighlighter.h"
#include <QTabWidget>
#include <QTreeView>
#include <QFileSystemModel>
#include <QPlainTextEdit>
#include <QSplitter>
#include <QDockWidget>
#include <QFileDialog>
#include <QFile>
#include <QFileInfo>
#include <QDir>
#include <QMenuBar>
#include <QMessageBox>
#include <QStatusBar>
#include <QProcess>
#include <QCloseEvent>
#include <QFontDatabase>
#include <QHeaderView>
#include <QAction>
#include <QRegularExpression>
#include <QStandardPaths>
#include <QTextCursor>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), tabs(new QTabWidget(this)),
    tree(new QTreeView(this)), fileModel(new QFileSystemModel(this)),
    output(new QPlainTextEdit(this)), process(new QProcess(this))
{
    setWindowTitle("Forja C++");
    resize(1200, 760);
    QFont mono = QFontDatabase::systemFont(QFontDatabase::FixedFont);
    mono.setPointSize(10);
    tabs->setTabsClosable(true);
    connect(tabs, &QTabWidget::tabCloseRequested, this, [this](int index) {
        QWidget *w = tabs->widget(index);
        for (int i = documents.size()-1; i >= 0; --i) {
            if (documents[i].editor == w) { documents.removeAt(i); break; }
        }
        tabs->removeTab(index); w->deleteLater();
        if (tabs->count() == 0) openFile();
    });
    fileModel->setRootPath(QDir::homePath());
    tree->setModel(fileModel);
    tree->setRootIndex(fileModel->index(QDir::homePath()));
    tree->setHeaderHidden(true);
    for (int i = 1; i < 4; ++i) tree->hideColumn(i);
    connect(tree, &QTreeView::doubleClicked, this, [this](const QModelIndex &idx) {
        if (fileModel->isDir(idx)) return;
        openFile(fileModel->filePath(idx));
    });
    output->setReadOnly(true); output->setFont(mono);
    output->setMaximumBlockCount(5000);
    splitter = new QSplitter(Qt::Horizontal, this);
    splitter->addWidget(tree);
    QSplitter *right = new QSplitter(Qt::Vertical, splitter);
    right->addWidget(tabs); right->addWidget(output);
    right->setStretchFactor(0, 4); right->setStretchFactor(1, 1);
    splitter->addWidget(right); splitter->setStretchFactor(1, 1);
    setCentralWidget(splitter);
    connect(process, &QProcess::readyReadStandardOutput, this, [this]() { appendOutput(QString::fromLocal8Bit(process->readAllStandardOutput())); });
    connect(process, &QProcess::readyReadStandardError, this, [this]() { appendOutput(QString::fromLocal8Bit(process->readAllStandardError())); });
    connect(process, &QProcess::errorOccurred, this, [this](QProcess::ProcessError) { appendOutput("\n[Forja] Não foi possível iniciar o processo. Verifique se a ferramenta está instalada e no PATH.\n"); });
    connect(process, qOverload<int, QProcess::ExitStatus>(&QProcess::finished), this, [this](int code, QProcess::ExitStatus) {
        appendOutput(QString("\n[Forja] Processo finalizado (código %1).\n").arg(code));
    });
    createMenus(); setTheme();
    statusBar()->showMessage("Pronto | F5: executar arquivo atual");
    openFile();
}
void MainWindow::setTheme()
{
    setStyleSheet(R"(
        QMainWindow, QMenuBar, QMenu, QStatusBar { background:#252830; color:#E5E9F0; }
        QMenuBar::item:selected, QMenu::item:selected { background:#3B4252; }
        QTabWidget::pane { border:1px solid #343944; }
        QTabBar::tab { background:#252830; color:#C8CDD8; padding:9px 14px; }
        QTabBar::tab:selected { background:#343944; color:#FFFFFF; }
        QTreeView, QPlainTextEdit { background:#1E2127; color:#D8DEE9; border:0; selection-background-color:#414B5E; }
        QHeaderView::section { background:#252830; color:#D8DEE9; }
    )");
}
void MainWindow::createMenus()
{
    auto file = menuBar()->addMenu("&Arquivo");
    auto open = file->addAction("Abrir arquivo...");
    open->setShortcut(QKeySequence::Open); connect(open, &QAction::triggered, this, [this]() { openFile(); });
    auto save = file->addAction("Salvar"); save->setShortcut(QKeySequence::Save);
    connect(save, &QAction::triggered, this, [this]() { saveFile(); });
    auto saveAs = file->addAction("Salvar como...");
    saveAs->setShortcut(QKeySequence("Ctrl+Shift+S")); connect(saveAs, &QAction::triggered, this, [this]() { saveFile(true); });
    file->addSeparator();
    auto quit = file->addAction("Sair"); connect(quit, &QAction::triggered, this, &QWidget::close);
    auto project = menuBar()->addMenu("&Projeto");
    auto folder = project->addAction("Abrir pasta...");
    connect(folder, &QAction::triggered, this, &MainWindow::openFolder);
    auto run = menuBar()->addMenu("&Executar");
    auto runAction = run->addAction("Executar arquivo atual"); runAction->setShortcut(Qt::Key_F5);
    connect(runAction, &QAction::triggered, this, &MainWindow::runCurrent);
}
CodeEditor *MainWindow::createEditor(const QString &text)
{
    auto *editor = new CodeEditor(this);
    editor->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
    editor->setStyleSheet("QPlainTextEdit { background:#1E2127; color:#D8DEE9; }");
    editor->setPlainText(text);
    return editor;
}
MainWindow::Document *MainWindow::currentDocument()
{
    QWidget *w = tabs->currentWidget();
    for (auto &doc : documents) if (doc.editor == w) return &doc;
    return nullptr;
}
void MainWindow::openFile(const QString &givenPath)
{
    QString path = givenPath;
    if (path.isEmpty()) path = QFileDialog::getOpenFileName(this, "Abrir arquivo", projectRoot.isEmpty() ? QDir::homePath() : projectRoot,
        "Código (*.c *.h *.java *.py *.rb *.txt *.cpp *.hpp);;Todos os arquivos (*.*)");
    if (path.isEmpty()) {
        if (tabs->count() == 0) {
            auto *editor = createEditor();
            auto *highlighter = new SyntaxHighlighter(editor->document());
            documents.append({QString(), editor, highlighter});
            tabs->addTab(editor, "Sem título");
        }
        return;
    }
    path = QDir::cleanPath(path);
    for (int i = 0; i < documents.size(); ++i) {
        if (documents[i].path.compare(path, Qt::CaseInsensitive) == 0) { tabs->setCurrentWidget(documents[i].editor); return; }
    }
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Forja C++", "Não foi possível abrir o arquivo.");
        return;
    }
    auto *editor = createEditor(QString::fromUtf8(f.readAll()));
    auto *highlighter = new SyntaxHighlighter(editor->document());
    documents.append({path, editor, highlighter});
    tabs->addTab(editor, QFileInfo(path).fileName());
    tabs->setCurrentWidget(editor);
    statusBar()->showMessage(path);
}
void MainWindow::saveFile(bool saveAs)
{
    Document *doc = currentDocument();
    if (!doc) return;
    QString path = doc->path;
    if (path.isEmpty() || saveAs) path = QFileDialog::getSaveFileName(this, "Salvar arquivo", path.isEmpty() ? projectRoot : path,
        "Todos os arquivos (*.*)");
    if (path.isEmpty()) return;
    QFile f(path);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Forja C++", "Não foi possível salvar o arquivo.");
        return;
    }
    f.write(doc->editor->toPlainText().toUtf8());
    doc->path = path;
    int idx = tabs->indexOf(doc->editor);
    if (idx >= 0) tabs->setTabText(idx, QFileInfo(path).fileName());
    statusBar()->showMessage("Salvo: " + path, 3000);
}
void MainWindow::openFolder()
{
    QString folder = QFileDialog::getExistingDirectory(this, "Abrir pasta de projeto", projectRoot.isEmpty() ? QDir::homePath() : projectRoot);
    if (folder.isEmpty()) return;
    projectRoot = folder;
    tree->setRootIndex(fileModel->index(folder));
    statusBar()->showMessage("Projeto: " + folder);
}
QString MainWindow::findTool(const QStringList &candidates) const
{
    for (const QString &candidate : candidates) {
        if (QFileInfo(candidate).isAbsolute() && QFileInfo::exists(candidate)) return candidate;
        QString found = QStandardPaths::findExecutable(candidate);
        if (!found.isEmpty()) return found;
    }
    return QString();
}
void MainWindow::runCurrent()
{
    Document *doc = currentDocument();
    if (!doc) return;
    if (doc->path.isEmpty()) {
        saveFile();
        doc = currentDocument();
        if (!doc || doc->path.isEmpty()) { appendOutput("[Forja] Salve o arquivo antes de executar.\n"); return; }
    } else {
        QFile f(doc->path);
        if (f.open(QIODevice::WriteOnly | QIODevice::Text)) f.write(doc->editor->toPlainText().toUtf8());
    }
    if (process->state() != QProcess::NotRunning) {
        appendOutput("[Forja] Já existe um processo em execução. Aguarde terminar.\n"); return;
    }
    const QFileInfo info(doc->path);
    const QString dir = info.absolutePath();
    const QString ext = info.suffix().toLower();
    QString program; QStringList args; QString runProgram; QStringList runArgs;
    if (ext == "c") {
        program = findTool({"gcc", "clang"});
        if (program.isEmpty()) { appendOutput("[Forja] GCC/Clang não encontrado. Instale um compilador C e adicione-o ao PATH.\n"); return; }
        const QString exe = dir + QDir::separator() + info.completeBaseName() + ".exe";
        args << info.absoluteFilePath() << "-o" << exe;
        runProgram = exe;
    } else if (ext == "java") {
        QString javac = findTool({"javac"});
        QString java = findTool({"java"});
        if (javac.isEmpty() || java.isEmpty()) { appendOutput("[Forja] JDK não encontrado. Instale um JDK e adicione sua pasta bin ao PATH.\n"); return; }
        program = javac; args << "-encoding" << "UTF-8" << info.absoluteFilePath();
        runProgram = java; runArgs << "-cp" << dir << info.completeBaseName();
    } else if (ext == "py") {
        program = findTool({"python", "py"});
        if (program.isEmpty()) { appendOutput("[Forja] Python não encontrado. Instale-o e marque a opção para adicioná-lo ao PATH.\n"); return; }
        if (QFileInfo(program).fileName().compare("py.exe", Qt::CaseInsensitive) == 0 || QFileInfo(program).fileName().compare("py", Qt::CaseInsensitive) == 0) args << "-3";
        args << info.absoluteFilePath();
        runProgram.clear();
    } else if (ext == "rb") {
        program = findTool({"ruby"});
        if (program.isEmpty()) { appendOutput("[Forja] Ruby não encontrado. Instale Ruby e adicione-o ao PATH.\n"); return; }
        args << info.absoluteFilePath();
    } else {
        appendOutput("[Forja] Extensão não suportada. Use .c, .java, .py ou .rb.\n"); return;
    }
    output->clear();
    appendOutput("[Forja] " + program + " " + args.join(" ") + "\n\n");
    process->setWorkingDirectory(dir);
    connect(process, &QProcess::finished, this, [this, runProgram, runArgs](int code, QProcess::ExitStatus) {
        Q_UNUSED(code);
        if (!runProgram.isEmpty()) {
            QString exe = runProgram;
            if (QFileInfo(exe).exists()) {
                appendOutput("\n[Forja] Executando programa compilado...\n");
                process->start(exe, runArgs);
            } else {
                appendOutput("\n[Forja] Compilação falhou; execução cancelada.\n");
            }
        }
    }, Qt::SingleShotConnection);
    process->start(program, args);
}
void MainWindow::appendOutput(const QString &text) { output->moveCursor(QTextCursor::End); output->insertPlainText(text); output->moveCursor(QTextCursor::End); }
void MainWindow::closeEvent(QCloseEvent *event)
{
    if (process->state() != QProcess::NotRunning) process->kill();
    event->accept();
}
