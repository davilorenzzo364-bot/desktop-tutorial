#include <QApplication>
#include "MainWindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QApplication::setApplicationName("Forja C++");
    QApplication::setOrganizationName("Forja");
    MainWindow window;
    window.show();
    return app.exec();
}
