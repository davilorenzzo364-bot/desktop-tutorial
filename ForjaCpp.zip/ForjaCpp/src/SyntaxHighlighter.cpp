#include "SyntaxHighlighter.h"
#include <QRegularExpression>
#include <QColor>
#include <QFont>

SyntaxHighlighter::SyntaxHighlighter(QTextDocument *parent) : QSyntaxHighlighter(parent)
{
    QTextCharFormat keyword; keyword.setForeground(QColor("#C792EA")); keyword.setFontWeight(QFont::DemiBold);
    rules.append({QRegularExpression("\\\\b(if|else|for|while|return|class|public|private|static|void|int|float|double|char|bool|true|false|null|None|def|import|from|print|puts|package|new|String|System)\\\\b"), keyword});
    QTextCharFormat string; string.setForeground(QColor("#C3E88D"));
    rules.append({QRegularExpression("\"([^\"\\\\\\\\]|\\\\\\\\.)*\"|'([^'\\\\\\\\]|\\\\\\\\.)*'"), string});
    QTextCharFormat comment; comment.setForeground(QColor("#697A86")); comment.setFontItalic(true);
    rules.append({QRegularExpression("//[^\\\\n]*|#[^\\\\n]*"), comment});
    QTextCharFormat number; number.setForeground(QColor("#F78C6C"));
    rules.append({QRegularExpression("\\\\b[0-9]+(\\\\.[0-9]+)?\\\\b"), number});
}
void SyntaxHighlighter::highlightBlock(const QString &text)
{
    for (const auto &rule : rules) {
        auto it = rule.pattern.globalMatch(text);
        while (it.hasNext()) {
            auto match = it.next();
            setFormat(match.capturedStart(), match.capturedLength(), rule.format);
        }
    }
}
